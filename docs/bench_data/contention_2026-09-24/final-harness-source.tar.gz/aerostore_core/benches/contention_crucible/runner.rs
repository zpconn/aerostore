use super::supervision::{
    invalidate_previous_report, private_json, report_path_from_arguments,
    unique_evidence_directory, with_cleanup_result, write_json, PrivateCaseFiles, ProcessGroup,
    DEFAULT_OUTPUT,
};
use super::{aerostore, model, oracle, postgres, workers};
use crate::extended_crucible::{metrics::StoreMetrics, model::Record};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::{mpsc, Arc};
use std::time::{Duration, Instant};

#[derive(Clone, Serialize, Deserialize)]
struct Config {
    engine: String,
    mode: String,
    workers: usize,
    families: usize,
    seconds: u64,
    max_messages: usize,
    message_interval_us: u64,
    seed: u64,
    hot_percent: u32,
    shm_mib: usize,
    oracle_budget: usize,
    global_time_predicates: bool,
    pg_url: Option<String>,
    output: PathBuf,
}
impl Default for Config {
    fn default() -> Self {
        Self {
            engine: "both".into(),
            mode: "all".into(),
            workers: 4,
            families: 16,
            seconds: 30,
            max_messages: 20_000,
            message_interval_us: 0,
            seed: 20260924,
            hot_percent: 80,
            shm_mib: 256,
            oracle_budget: 2_000_000,
            global_time_predicates: false,
            pg_url: None,
            output: DEFAULT_OUTPUT.into(),
        }
    }
}

#[derive(Clone, Serialize, Deserialize)]
struct CaseConfig {
    config: Config,
    engine: String,
    scenario: Option<usize>,
    directory: PathBuf,
    schema: String,
}

struct Worker {
    child: Child,
    input: BufWriter<ChildStdin>,
}
impl Worker {
    fn spawn(
        config: &workers::Config,
        path: &Path,
        number: usize,
        events: mpsc::Sender<(usize, Result<workers::Reply, String>)>,
    ) -> Result<Self, String> {
        private_json(path, config)?;
        let mut child = Command::new(std::env::current_exe().map_err(|e| e.to_string())?)
            .arg("--internal-worker")
            .arg(path)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::inherit())
            .spawn()
            .map_err(|e| e.to_string())?;
        let input = BufWriter::new(child.stdin.take().ok_or("worker stdin unavailable")?);
        let output = child.stdout.take().ok_or("worker stdout unavailable")?;
        std::thread::spawn(move || {
            for line in BufReader::new(output).lines() {
                let reply = line.map_err(|e| e.to_string()).and_then(|line| {
                    serde_json::from_str(&line).map_err(|e| format!("worker protocol: {e}"))
                });
                if events.send((number, reply)).is_err() {
                    return;
                }
            }
            let _ = events.send((number, Err("worker output closed".into())));
        });
        Ok(Self { child, input })
    }
    fn send(&mut self, request: &workers::Request) -> Result<(), String> {
        serde_json::to_writer(&mut self.input, request).map_err(|e| e.to_string())?;
        writeln!(self.input).map_err(|e| e.to_string())?;
        self.input.flush().map_err(|e| e.to_string())
    }
    fn stop(&mut self) -> Result<(), String> {
        self.send(&workers::Request::Stop)?;
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            if let Some(status) = self.child.try_wait().map_err(|e| e.to_string())? {
                return if status.success() {
                    Ok(())
                } else {
                    Err(format!("worker exit {status}"))
                };
            }
            if Instant::now() >= deadline {
                return Err("worker shutdown exceeded 10 seconds".into());
            }
            std::thread::sleep(Duration::from_millis(5));
        }
    }
}
impl Drop for Worker {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

struct Completed {
    receipts: Vec<oracle::Receipt>,
    latencies: Vec<u64>,
    retries: u64,
    message_retries: Vec<u64>,
    worker_stops: Vec<Value>,
    metrics: StoreMetrics,
    causes: BTreeMap<String, u64>,
    samples: Vec<Value>,
    elapsed: f64,
    completed_by_worker: Vec<usize>,
}

fn exercise(
    case: &CaseConfig,
    initial: &[Record],
    messages: Option<&[model::Message]>,
    synchronise: bool,
    attachment: Option<aerostore::Attachment>,
    mut sample: impl FnMut() -> Result<Value, String>,
) -> Result<Completed, String> {
    let cfg = &case.config;
    // The small exact scenarios use one process per distinct message so the
    // controlled empty-search cut can never be hidden by worker queueing.
    let count = messages.map_or(cfg.workers, <[model::Message]>::len);
    let (send, receive) = mpsc::channel();
    let mut pool = Vec::new();
    for id in 0..count {
        let worker = workers::Config {
            engine: case.engine.clone(),
            attachment: attachment.clone(),
            pg_url: cfg.pg_url.clone(),
            schema: case.schema.clone(),
            global_time_predicates: cfg.global_time_predicates,
            worker_id: id,
            workers: count,
            families: cfg.families,
            seed: cfg.seed,
            hot_percent: cfg.hot_percent,
            retry_limit: 128,
            message_interval_us: cfg.message_interval_us,
            expected_parent_pid: std::process::id(),
        };
        pool.push(Worker::spawn(
            &worker,
            &case.directory.join(format!("worker-{id}.json")),
            id,
            send.clone(),
        )?);
    }
    drop(send);
    let mut ready = BTreeSet::new();
    while ready.len() < count {
        let (id, event) = receive
            .recv_timeout(Duration::from_secs(30))
            .map_err(|e| format!("worker ready timeout: {e}"))?;
        match event? {
            workers::Reply::Ready if ready.insert(id) => {}
            other => return Err(format!("unexpected worker startup event: {other:?}")),
        }
    }
    let sample_start = workers::monotonic_ns();
    let initial_sample = sample()?;
    let sample_end = workers::monotonic_ns();
    let started = Instant::now();
    let deadline_ns =
        workers::monotonic_ns().saturating_add(cfg.seconds.saturating_mul(1_000_000_000));
    for (id, worker) in pool.iter_mut().enumerate() {
        let request = match messages {
            Some(messages) => workers::Request::Run {
                messages: vec![messages[id].clone()],
                synchronise_first_query: synchronise,
            },
            None => workers::Request::Sustain {
                deadline_ns,
                max_messages: cfg.max_messages,
            },
        };
        worker.send(&request)?;
    }
    let mut result = Completed {
        receipts: Vec::new(),
        latencies: Vec::new(),
        retries: 0,
        message_retries: Vec::new(),
        worker_stops: vec![Value::Null; count],
        metrics: StoreMetrics::default(),
        causes: BTreeMap::new(),
        samples: Vec::new(),
        elapsed: 0.,
        completed_by_worker: vec![0; count],
    };
    result.samples.push(json!({"elapsed_seconds":0.0,"completed_messages":0,"storage":initial_sample,"sample_started_ns":sample_start,"sample_finished_ns":sample_end}));
    let mut last_sample = Instant::now();
    let mut last_progress = Instant::now();
    let mut first_queries = BTreeSet::new();
    let mut done = BTreeSet::new();
    // Raw successful receipts are retained, even if a later operation fails.
    let mut history = BufWriter::new(
        fs::File::create(case.directory.join("history.jsonl")).map_err(|e| e.to_string())?,
    );
    while done.len() < count {
        match receive.recv_timeout(Duration::from_millis(100)) {
            Ok((id, event)) => {
                if done.contains(&id) {
                    return Err(format!("worker {id} emitted after Done"));
                }
                match event? {
                    workers::Reply::FirstQuery { rows }
                        if synchronise && first_queries.insert(id) =>
                    {
                        if rows != 0 {
                            return Err(
                                "competing creation did not observe an empty candidate query"
                                    .into(),
                            );
                        }
                        if first_queries.len() == count {
                            for worker in &mut pool {
                                worker.send(&workers::Request::Continue)?;
                            }
                        }
                    }
                    workers::Reply::Observation {
                        receipt,
                        latency_ns,
                        retries,
                    } => {
                        if messages.is_some_and(|m| receipt.message != m[id]) {
                            return Err("worker returned wrong scenario message".into());
                        }
                        if let Some(expected) = messages {
                            if result.completed_by_worker[id] != 0 || expected.len() != count {
                                return Err("duplicate scenario completion".into());
                            }
                        } else {
                            let sequence =
                                result.completed_by_worker[id] as u64 * count as u64 + id as u64;
                            let expected = model::sustained_message(
                                sequence,
                                id,
                                count,
                                cfg.families,
                                cfg.seed,
                                cfg.hot_percent,
                            );
                            if receipt.message != expected {
                                return Err(
                                    "sustained message stream differs from deterministic generator"
                                        .into(),
                                );
                            }
                        }
                        serde_json::to_writer(&mut history, &json!({"worker":id,"latency_ns":latency_ns,"retries":retries,"receipt":receipt}))
                            .map_err(|e| e.to_string())?;
                        writeln!(history).map_err(|e| e.to_string())?;
                        result.receipts.push(receipt);
                        result.latencies.push(latency_ns);
                        result.retries += retries;
                        result.message_retries.push(retries);
                        result.completed_by_worker[id] += 1;
                    }
                    workers::Reply::Done {
                        metrics,
                        retry_causes,
                        finished_ns,
                        stop_reason,
                    } if done.insert(id) => {
                        if finished_ns > workers::monotonic_ns()
                            || (stop_reason == "deadline" && finished_ns < deadline_ns)
                        {
                            return Err("invalid worker finish clock".into());
                        }
                        if messages.is_some() && stop_reason != "scenario_complete" {
                            return Err("scenario worker stopped early".into());
                        }
                        if messages.is_none()
                            && !["deadline", "message_cap"].contains(&stop_reason.as_str())
                        {
                            return Err("invalid sustained stop reason".into());
                        }
                        result.worker_stops[id] =
                            json!({"finished_ns":finished_ns,"stop_reason":stop_reason});
                        result.metrics.add(&metrics);
                        for (cause, count) in retry_causes {
                            *result.causes.entry(cause).or_default() += count;
                        }
                    }
                    workers::Reply::Error { message } => {
                        return Err(format!("worker {id}: {message}"))
                    }
                    other => return Err(format!("unexpected worker event: {other:?}")),
                }
                last_progress = Instant::now();
            }
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                return Err("all worker streams closed before completion".into())
            }
            Err(mpsc::RecvTimeoutError::Timeout) => {}
        }
        if last_sample.elapsed() >= Duration::from_secs(1) {
            history.flush().map_err(|e| e.to_string())?;
            let sample_start = workers::monotonic_ns();
            let storage = sample()?;
            let sample_end = workers::monotonic_ns();
            result
                .samples
                .push(json!({"elapsed_seconds":started.elapsed().as_secs_f64(),
                "sample_started_ns":sample_start,"sample_finished_ns":sample_end,
                "completed_messages":result.receipts.len(),"storage":storage}));
            write_json(
                &case.directory.join("progress.json"),
                &json!({"passed":false,"execution_completed":false,"completed_messages":result.receipts.len(),"completed_by_worker":result.completed_by_worker,"retries":result.retries,"retention_samples":result.samples}),
            )?;
            last_sample = Instant::now();
        }
        if last_progress.elapsed() > Duration::from_secs(60) {
            return Err("no worker progress for 60 seconds".into());
        }
    }
    result.elapsed = started.elapsed().as_secs_f64();
    history.flush().map_err(|e| e.to_string())?;
    for worker in &mut pool {
        worker.stop()?;
    }
    for id in 0..count {
        let _ = fs::remove_file(case.directory.join(format!("worker-{id}.json")));
    }
    if result.receipts.is_empty() || result.completed_by_worker.contains(&0) {
        return Err("a worker completed zero messages".into());
    }
    if result.metrics.commits != result.receipts.len() as u64 {
        return Err("receipt count differs from successful native commits".into());
    }
    if synchronise && first_queries.len() != count {
        return Err("required simultaneous empty-search cut was not reached".into());
    }
    let _ = initial;
    Ok(result)
}

fn summarize(
    case: &CaseConfig,
    initial: &[Record],
    final_rows: &[Record],
    mut completed: Completed,
    audit: Value,
    drained: Value,
) -> Result<Value, String> {
    let invariants = model::validate_snapshot(final_rows);
    let invariant_passed = invariants.is_ok();
    let invariants = match invariants {
        Ok(report) => json!({"passed":true,"checks":report}),
        Err(error) => json!({"passed":false,"error":error}),
    };
    let mut per_kind = BTreeMap::<String, (Vec<u64>, u64, [usize; 5])>::new();
    for (i, receipt) in completed.receipts.iter().enumerate() {
        let name = match receipt.message.kind {
            model::MessageKind::Plan => "plan",
            model::MessageKind::Position { .. } => "position",
            model::MessageKind::Project { .. } => "projection",
            model::MessageKind::Housekeeping { .. } => "housekeeping",
            model::MessageKind::Rename { .. } => "key_move",
            model::MessageKind::Arrival => "arrival",
        };
        let (latencies, retries, outcome) = per_kind.entry(name.into()).or_default();
        latencies.push(completed.latencies[i]);
        *retries += completed.message_retries[i];
        outcome[0] += receipt.body.outcome.updated_views;
        outcome[1] += receipt.body.outcome.created_views;
        outcome[2] += receipt.body.outcome.ignored_stale;
        outcome[3] += receipt.body.outcome.expired_records;
        outcome[4] += receipt.body.outcome.outputs.len();
    }
    let per_kind: BTreeMap<_,_> = per_kind.into_iter().map(|(name,(mut latencies,retries,outcome))| {
        latencies.sort_unstable();
        (name,json!({"completed":latencies.len(),"retries":retries,"p99_us_including_retries":latencies[(latencies.len()*99).div_ceil(100)-1] as f64 / 1000.0,"outcomes":{"updated_views":outcome[0],"created_views":outcome[1],"ignored_stale":outcome[2],"expired_records":outcome[3],"outputs":outcome[4]}}))
    }).collect();
    completed.latencies.sort_unstable();
    let quantile = |percent: usize| {
        completed.latencies[(completed.latencies.len() * percent).div_ceil(100) - 1] as f64 / 1000.
    };
    write_json(&case.directory.join("initial.json"), &initial)?;
    write_json(&case.directory.join("final.json"), &final_rows)?;
    let checking = Instant::now();
    let witness = oracle::check(
        initial,
        &completed.receipts,
        final_rows,
        case.config.oracle_budget,
    );
    write_json(&case.directory.join("serial-witness.json"), &witness)?;
    let passed = witness.status == oracle::Status::Valid && invariant_passed;
    let count = completed.receipts.len();
    let mut kinds = BTreeMap::<String, usize>::new();
    for receipt in &completed.receipts {
        let name = match receipt.message.kind {
            model::MessageKind::Plan => "plan",
            model::MessageKind::Position { .. } => "position",
            model::MessageKind::Project { .. } => "projection",
            model::MessageKind::Housekeeping { .. } => "housekeeping",
            model::MessageKind::Rename { .. } => "key_move",
            model::MessageKind::Arrival => "arrival",
        };
        *kinds.entry(name.into()).or_default() += 1;
    }
    Ok(
        json!({"engine":case.engine,"scenario":case.scenario.map_or("sustained-mixed".to_owned(), |i| model::scenarios(case.config.seed)[i].name.clone()),
        "passed":passed,"execution_completed":true,"oracle_status":witness.status,"oracle_explored":witness.explored,
        "oracle_detail":witness.detail,"oracle_seconds":checking.elapsed().as_secs_f64(),
        "completed_messages":count,"completed_by_worker":completed.completed_by_worker,"message_kinds":kinds,
        "per_kind":per_kind,"invariants":invariants,"worker_stops":completed.worker_stops,
        "elapsed_seconds":completed.elapsed,"completed_messages_per_second":count as f64 / completed.elapsed,
        "message_latency_p50_us_including_retries":quantile(50),"message_latency_p99_us_including_retries":quantile(99),
        "message_latency_max_us_including_retries":quantile(100),"retries":completed.retries,"retry_causes":completed.causes,
        "store_metrics":completed.metrics,"retention_samples":completed.samples,"after_drain":drained,"native_audit":audit,
        "evidence_directory":case.directory,"timing_contract":"instrumented closed-loop completion throughput includes process/receipt IPC; service latency includes full query/write recording, retries/backoff, excludes queue/IPC; scenarios include their deliberate first-query wait; oracle and final audit are outside timing",
        "retry_cause_limit":"native stages do not distinguish exact predicate bucket collisions, row validation or underlying newer-stamp causes; PostgreSQL reports SQLSTATE",
        "requested_duration_reached":case.scenario.is_none() && completed.worker_stops.iter().all(|s| s["stop_reason"] == "deadline"),
        "worker_message_cap_reached":completed.worker_stops.iter().any(|s| s["stop_reason"] == "message_cap"),
        "performance_comparison_eligible":false,
        "performance_scope":"diagnostic instrumented workload; repeated matched trials, noise analysis and availability acceptance are required before architecture promotion",
        "worker_failure_availability_tested":false}),
    )
}

fn coordinator(case: &CaseConfig) -> Result<Value, String> {
    let scenario = case
        .scenario
        .map(|i| model::scenarios(case.config.seed).remove(i));
    let initial = scenario.as_ref().map_or_else(
        || model::sustained_initial(case.config.families, case.config.seed),
        |s| s.initial.clone(),
    );
    let messages = scenario.as_ref().map(|s| s.messages.as_slice());
    let synchronise = scenario.as_ref().is_some_and(|s| s.synchronise_first_query);
    if case.engine == "postgres" {
        let url = case
            .config
            .pg_url
            .as_deref()
            .ok_or("missing PostgreSQL URL")?;
        postgres::initialize(url, &case.schema, &initial)?;
        let execution = (|| {
            let completed = exercise(case, &initial, messages, synchronise, None, || {
                postgres::retention(url, &case.schema)
            })?;
            let final_rows = postgres::snapshot(url, &case.schema)?;
            summarize(
                case,
                &initial,
                &final_rows,
                completed,
                Value::Null,
                postgres::retention(url, &case.schema)?,
            )
        })();
        let cleanup = postgres::cleanup(url, &case.schema);
        return match (execution, cleanup) {
            (Ok(report), Ok(())) => Ok(report),
            (Err(e), _) => Err(e),
            (_, Err(e)) => Err(e),
        };
    }
    let path = case.directory.join("arena.mmap");
    let shared = aerostore::Shared::create(&path, case.config.shm_mib << 20, &initial)?;
    // Fork helpers before reader/vacuum threads exist in this coordinator.
    let writer =
        aerostore_core::spawn_wal_writer_daemon(shared.ring.clone(), &case.directory.join("wal"))
            .map_err(|e| e.to_string())?;
    let collectors = shared
        .indexes
        .iter()
        .map(|i| {
            i.spawn_gc_daemon(Duration::from_millis(25))
                .map_err(|e| e.to_string())
        })
        .collect::<Result<Vec<_>, _>>()?;
    // Error unwinding must not join a collector blocked by an abandoned native
    // lock. The isolated coordinator's process group is killed by its parent.
    let vacuum = std::mem::ManuallyDrop::new(
        aerostore_core::spawn_vacuum_daemon_with_config(
            Arc::clone(&shared.table),
            aerostore_core::VacuumDaemonConfig::default().with_interval(Duration::from_millis(25)),
        )
        .map_err(|e| e.to_string())?,
    );
    let completed = exercise(
        case,
        &initial,
        messages,
        synchronise,
        Some(shared.attachment(&path)),
        || aerostore::retention(&shared),
    )?;
    vacuum.stop().map_err(|e| e.to_string())?;
    for collector in &collectors {
        collector.stop().map_err(|e| e.to_string())?;
    }
    shared.ring.close().map_err(|e| e.to_string())?;
    writer.join().map_err(|e| e.to_string())?;
    aerostore_core::run_vacuum_pass(&shared.table).map_err(|e| e.to_string())?;
    let final_rows = shared.snapshot()?;
    let audit = shared.audit()?;
    if !shared.arena.create_snapshot().is_empty() {
        return Err("registrations remain after worker exit".into());
    }
    let report = summarize(
        case,
        &initial,
        &final_rows,
        completed,
        audit,
        aerostore::retention(&shared)?,
    )?;
    // Full logical evidence is retained; large disposable storage isn't an archive.
    let _ = fs::remove_file(&path);
    let _ = fs::remove_file(case.directory.join("wal"));
    Ok(report)
}

fn cleanup_postgres_case(case: &CaseConfig, config_path: &Path) -> Result<(), String> {
    if case.engine != "postgres" {
        return Ok(());
    }
    // Even if the coordinator died before its cleanup path, its workers have
    // now been killed. Bound cleanup separately, including connection hangs.
    // The adapter checks the schema's ownership marker before dropping it.
    let mut command = Command::new(std::env::current_exe().map_err(|e| e.to_string())?);
    command
        .arg("--internal-pg-cleanup")
        .arg(config_path)
        .stdin(Stdio::null());
    let mut cleanup = ProcessGroup::spawn(command)?;
    let status = cleanup.wait(Duration::from_secs(75))?;
    if status.success() {
        Ok(())
    } else {
        Err(format!("PostgreSQL cleanup process exited {status}"))
    }
}

fn isolated_case(case: &CaseConfig) -> Result<Value, String> {
    fs::create_dir(&case.directory).map_err(|e| e.to_string())?;
    let _private_files = PrivateCaseFiles(case.directory.clone());
    let config_path = case.directory.join("private-config.json");
    private_json(&config_path, case)?;
    let execution = (|| {
        let mut command = Command::new(std::env::current_exe().map_err(|e| e.to_string())?);
        command
            .arg("--internal-coordinator")
            .arg(&config_path)
            .stdin(Stdio::null());
        let mut child = ProcessGroup::spawn(command)?;
        let status = child.wait(Duration::from_secs(case.config.seconds + 300))?;
        if !status.success() {
            return Err(format!("coordinator exited {status}"));
        }
        serde_json::from_slice(
            &fs::read(case.directory.join("result.json")).map_err(|e| e.to_string())?,
        )
        .map_err(|e| e.to_string())
    })();
    // The group guard has already terminated/reaped the coordinator here;
    // external database cleanup cannot race a surviving fixture worker.
    let cleanup = cleanup_postgres_case(case, &config_path);
    with_cleanup_result(execution, cleanup, &case.schema)
}

fn parse() -> Result<Option<Config>, String> {
    let mut config = Config::default();
    let mut args = std::env::args().skip(1);
    while let Some(arg) = args.next() {
        if arg == "--help" {
            println!("HyperFeed contention Crucible\n--engine both|aerostore|postgres --mode all|scenarios|sustained\n--workers 4 --families 16 --seconds 30 --max-messages 20000 (per worker) --message-interval-us 0\n--seed 20260924 --hot-percent 80 --shm-mib 256 --oracle-budget 2000000\n--query-plan family|global-time --pg-url URL --output target/contention-crucible.json\n\nNo declared write sets or application prelocks. Complete successful histories must\nhave a serial witness; exhausted oracle budgets are INCONCLUSIVE and fail the run.\nBoth engines use asynchronous WAL acknowledgement; crash durability is not equated.\n--pg-url is required for both/postgres; start and manage the comparison server explicitly.");
            return Ok(None);
        }
        if arg == "--bench" || arg == "--noplot" {
            continue;
        }
        let value = args
            .next()
            .ok_or_else(|| format!("missing value for {arg}"))?;
        match arg.as_str() {
            "--engine" => config.engine = value,
            "--mode" => config.mode = value,
            "--workers" => config.workers = value.parse().map_err(|_| "invalid workers")?,
            "--families" => config.families = value.parse().map_err(|_| "invalid families")?,
            "--seconds" => config.seconds = value.parse().map_err(|_| "invalid seconds")?,
            "--max-messages" => {
                config.max_messages = value.parse().map_err(|_| "invalid message cap")?
            }
            "--message-interval-us" => {
                config.message_interval_us =
                    value.parse().map_err(|_| "invalid message interval")?
            }
            "--seed" => config.seed = value.parse().map_err(|_| "invalid seed")?,
            "--hot-percent" => {
                config.hot_percent = value.parse().map_err(|_| "invalid hot-percent")?
            }
            "--shm-mib" => config.shm_mib = value.parse().map_err(|_| "invalid shm-mib")?,
            "--oracle-budget" => {
                config.oracle_budget = value.parse().map_err(|_| "invalid oracle budget")?
            }
            "--query-plan" => {
                config.global_time_predicates = match value.as_str() {
                    "family" => false,
                    "global-time" => true,
                    _ => return Err("invalid query plan".into()),
                }
            }
            "--pg-url" => config.pg_url = Some(value),
            "--output" => config.output = value.into(),
            _ => return Err(format!("unknown option {arg}")),
        }
    }
    if !["both", "aerostore", "postgres"].contains(&config.engine.as_str())
        || !["all", "scenarios", "sustained"].contains(&config.mode.as_str())
        || !(1..=32).contains(&config.workers)
        || !(1..=128).contains(&config.families)
        || !(1..=3600).contains(&config.seconds)
        || !(1..=100_000).contains(&config.max_messages)
        || config.message_interval_us > 1_000_000
        || config.hot_percent > 100
        || !(32..=3584).contains(&config.shm_mib)
        || config.oracle_budget == 0
    {
        return Err("invalid configuration; use --help (bounded workers/families/duration/history capacity)".into());
    }
    Ok(Some(config))
}

fn run_engines(config: &Config, evidence: &Path, report: &mut Value) -> Result<(), String> {
    let engines: Vec<_> = if config.engine == "both" {
        vec!["aerostore", "postgres"]
    } else {
        vec![config.engine.as_str()]
    };
    for engine in engines {
        let mut cases: Vec<Option<usize>> = if config.mode == "sustained" {
            vec![]
        } else {
            (0..model::scenarios(config.seed).len()).map(Some).collect()
        };
        if config.mode != "scenarios" {
            cases.push(None);
        }
        for (number, scenario) in cases.into_iter().enumerate() {
            let case = CaseConfig {
                config: config.clone(),
                engine: engine.into(),
                scenario,
                directory: evidence.join(format!("{engine}-{number}")),
                schema: format!(
                    "aero_contention_{}_{:x}_{}",
                    std::process::id(),
                    workers::monotonic_ns(),
                    number
                ),
            };
            let result = isolated_case(&case).unwrap_or_else(|error| json!({"engine":engine,"scenario":scenario,"passed":false,"execution_completed":false,"error":error,"evidence_directory":case.directory}));
            if engine == "postgres" && result["postgres_configuration"].is_object() {
                report["postgres_configuration"] = result["postgres_configuration"].clone();
            }
            println!("contention_crucible engine={engine} scenario={} passed={} completed={} retries={} p99_us={}",
                result["scenario"],result["passed"],result["completed_messages"],result["retries"],result["message_latency_p99_us_including_retries"]);
            report["runs"].as_array_mut().unwrap().push(result);
            write_json(&config.output, report)?;
        }
    }
    Ok(())
}

pub fn run() -> Result<(), String> {
    let arguments: Vec<_> = std::env::args().collect();
    if arguments.get(1).is_some_and(|a| a == "--internal-worker") {
        return workers::worker_main(Path::new(arguments.get(2).ok_or("missing worker config")?));
    }
    if arguments
        .get(1)
        .is_some_and(|a| a == "--internal-pg-cleanup")
    {
        let path = Path::new(arguments.get(2).ok_or("missing cleanup config")?);
        let case: CaseConfig = serde_json::from_slice(&fs::read(path).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
        return postgres::cleanup(
            case.config
                .pg_url
                .as_deref()
                .ok_or("missing PostgreSQL connection")?,
            &case.schema,
        );
    }
    if arguments
        .get(1)
        .is_some_and(|a| a == "--internal-coordinator")
    {
        let path = Path::new(arguments.get(2).ok_or("missing coordinator config")?);
        let case: CaseConfig = serde_json::from_slice(&fs::read(path).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
        // Server metadata collection belongs inside the same bounded process
        // as execution; a broken network must not hang the top-level runner.
        let configuration = if case.engine == "postgres" {
            postgres::configuration(
                case.config
                    .pg_url
                    .as_deref()
                    .ok_or("missing PostgreSQL connection")?,
                false,
            )
        } else {
            Ok(Value::Null)
        };
        let result = configuration.and_then(|configuration| {
            coordinator(&case).map(|mut report| {
                if case.engine == "postgres" { report["postgres_configuration"] = configuration; }
                report
            })
        }).unwrap_or_else(|error| json!({"engine":case.engine,"scenario":case.scenario,"passed":false,"execution_completed":false,"error":error,"evidence_directory":case.directory}));
        write_json(&case.directory.join("result.json"), &result)?;
        // Skip destructors for any abandoned native critical section on errors.
        std::process::exit(0);
    }
    // Invalidate stale success before parsing or any other fallible setup. Help
    // is informational and deliberately leaves a previous run untouched.
    if arguments.iter().any(|arg| arg == "--help") {
        parse()?;
        return Ok(());
    }
    let output = invalidate_previous_report(&report_path_from_arguments(&arguments))?;
    let mut config = match parse() {
        Ok(Some(config)) => config,
        Ok(None) => return Ok(()),
        Err(error) => {
            write_json(
                &output,
                &json!({"schema":1,"completed":false,"passed":false,
                "stage":"configuration","runs":[],"operational_error":error}),
            )?;
            return Err(error);
        }
    };
    config.output = output;
    let mut public_config = serde_json::to_value(&config).map_err(|e| e.to_string())?;
    public_config.as_object_mut().unwrap().remove("pg_url");
    let mut report = json!({"schema":1,"completed":false,"passed":false,"config":public_config,"runs":[],
        "git_revision":null,"evidence_directory":null,
        "transaction_contract":"single-table native optimistic transactions versus PostgreSQL SERIALIZABLE; dynamic reads/writes, no family prelocks; strict serial witness checked for every successful attempt",
        "durability_contract":"both use WAL with asynchronous acknowledgement; fsync on PostgreSQL; native writer drained on normal completion; equal crash loss windows and crash recovery NOT claimed",
        "scope":"synthetic harder HyperFeed storage workload, not proprietary handler compatibility or architecture superiority",
        "worker_failure_requirement":"surviving workers must continue; separate worker_failure_contract test reports current violations",
        "whole_engine_verified":false,"architecture_promotion_eligible":false});
    write_json(&config.output, &report)?;
    let outcome = (|| {
        if config.engine != "aerostore" && config.pg_url.as_deref().is_none_or(str::is_empty) {
            return Err("--pg-url is required for both/postgres; manage the comparison PostgreSQL server explicitly".into());
        }
        let evidence = unique_evidence_directory(&config.output)?;
        report["evidence_directory"] = json!(evidence);
        let git = Command::new("git")
            .args(["rev-parse", "HEAD"])
            .output()
            .map_err(|e| e.to_string())?;
        if !git.status.success() {
            return Err("cannot record baseline git revision".into());
        }
        report["git_revision"] = json!(String::from_utf8_lossy(&git.stdout).trim());
        write_json(&config.output, &report)?;
        run_engines(&config, &evidence, &mut report)
    })();
    report["completed"] = json!(outcome.is_ok());
    if let Err(error) = &outcome {
        report["operational_error"] = json!(error);
    }
    report["passed"] = json!(
        outcome.is_ok()
            && !report["runs"].as_array().unwrap().is_empty()
            && report["runs"]
                .as_array()
                .unwrap()
                .iter()
                .all(|r| r["passed"] == true)
    );
    write_json(&config.output, &report)?;
    if report["passed"] == true {
        Ok(())
    } else {
        Err(format!(
            "contention correctness/progress check failed: {}",
            config.output.display()
        ))
    }
}
