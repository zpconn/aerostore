//! Query-driven PostgreSQL adapter: SERIALIZABLE without predeclared writes or prelocks.
use std::collections::BTreeMap;
use std::time::Duration;

use ::postgres::{Client, Config, NoTls, Row, Statement};

use crate::extended_crucible::metrics::StoreMetrics;
use crate::extended_crucible::model::{DbError, Query, Record, Store};

const OWNERSHIP_MARKER: &str = "aerostore contention-crucible disposable schema v1";
const COLUMNS: &str = "id, active, kind, family, pedigree, callsign, tail, origin, destination, \
    scheduled, event_time, due, latitude, longitude, altitude, ground_speed, status, revision, \
    source, parent, sequence";

struct Queries {
    candidates: Statement,
    family: Statement,
    positions: Statement,
    due: Statement,
    expired: Statement,
    all: Statement,
}

pub struct Adapter {
    pub metrics: StoreMetrics,
    client: Client,
    read_statement: Statement,
    write_statement: Statement,
    queries: Queries,
    open: bool,
    /// Rejections by operation and server SQLSTATE; never inferred from timings.
    pub retry_causes: BTreeMap<String, u64>,
    savepoints: Vec<usize>,
    next_savepoint: usize,
}

fn schema_name(schema: &str) -> Result<String, String> {
    if schema.is_empty()
        || schema.len() > 63
        || !schema
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || byte == b'_')
    {
        return Err(
            "scratch schema must contain 1..=63 ASCII letters, digits, or underscores".into(),
        );
    }
    Ok(format!("\"{schema}\""))
}

fn connect_client(url: &str, synchronous_commit: bool) -> Result<Client, String> {
    let mut config: Config = url.parse().map_err(pg_error)?;
    config.connect_timeout(Duration::from_secs(5));
    let mut client = config.connect(NoTls).map_err(pg_error)?;
    client
        .batch_execute(&format!(
            "SET application_name = 'aerostore-contention-crucible'; \
         SET synchronous_commit = {}; SET statement_timeout = '60s';",
            if synchronous_commit { "on" } else { "off" }
        ))
        .map_err(pg_error)?;
    Ok(client)
}

fn pg_error(error: ::postgres::Error) -> String {
    match error.as_db_error() {
        Some(database) => format!(
            "{} (SQLSTATE {}{})",
            database.message(),
            database.code().code(),
            database
                .detail()
                .map(|detail| format!("; {detail}"))
                .unwrap_or_default(),
        ),
        None => error.to_string(),
    }
}

fn retry_sqlstate(code: &str) -> bool {
    matches!(code, "40001" | "40P01")
}

fn decode(row: &Row) -> Result<Record, String> {
    let id: i64 = row.try_get("id").map_err(pg_error)?;
    Ok(Record {
        id: usize::try_from(id).map_err(|_| format!("invalid PostgreSQL row id {id}"))?,
        active: row.try_get("active").map_err(pg_error)?,
        kind: row.try_get("kind").map_err(pg_error)?,
        family: row.try_get("family").map_err(pg_error)?,
        pedigree: row.try_get("pedigree").map_err(pg_error)?,
        callsign: row.try_get("callsign").map_err(pg_error)?,
        tail: row.try_get("tail").map_err(pg_error)?,
        origin: row.try_get("origin").map_err(pg_error)?,
        destination: row.try_get("destination").map_err(pg_error)?,
        scheduled: row.try_get("scheduled").map_err(pg_error)?,
        event_time: row.try_get("event_time").map_err(pg_error)?,
        due: row.try_get("due").map_err(pg_error)?,
        latitude: row.try_get("latitude").map_err(pg_error)?,
        longitude: row.try_get("longitude").map_err(pg_error)?,
        altitude: row.try_get("altitude").map_err(pg_error)?,
        ground_speed: row.try_get("ground_speed").map_err(pg_error)?,
        status: row.try_get("status").map_err(pg_error)?,
        revision: row.try_get("revision").map_err(pg_error)?,
        source: row.try_get("source").map_err(pg_error)?,
        parent: row.try_get("parent").map_err(pg_error)?,
        sequence: row.try_get("sequence").map_err(pg_error)?,
    })
}

fn record_parameters<'a>(
    row: &'a Record,
    id: &'a i64,
) -> [&'a (dyn ::postgres::types::ToSql + Sync); 21] {
    [
        id,
        &row.active,
        &row.kind,
        &row.family,
        &row.pedigree,
        &row.callsign,
        &row.tail,
        &row.origin,
        &row.destination,
        &row.scheduled,
        &row.event_time,
        &row.due,
        &row.latitude,
        &row.longitude,
        &row.altitude,
        &row.ground_speed,
        &row.status,
        &row.revision,
        &row.source,
        &row.parent,
        &row.sequence,
    ]
}

pub fn initialize(url: &str, schema: &str, records: &[Record]) -> Result<(), String> {
    let schema = schema_name(schema)?;
    let mut client = connect_client(url, false)?;
    let fsync: String = client
        .query_one("SHOW fsync", &[])
        .map_err(pg_error)?
        .get(0);
    if fsync != "on" {
        return Err(format!("PostgreSQL requires fsync=on; observed {fsync}"));
    }
    let mut transaction = client.transaction().map_err(pg_error)?;
    // CREATE, rather than DROP/CREATE or IF NOT EXISTS, prevents an accidental
    // collision from mutating an existing user schema.
    transaction
        .batch_execute(&format!(
            "CREATE SCHEMA {schema}; \
         COMMENT ON SCHEMA {schema} IS '{OWNERSHIP_MARKER}'; \
         CREATE TABLE {schema}.records ( \
           id bigint PRIMARY KEY, active boolean NOT NULL, kind bigint NOT NULL, \
           family bigint NOT NULL, pedigree bigint NOT NULL, callsign bigint NOT NULL, \
           tail bigint NOT NULL, origin bigint NOT NULL, destination bigint NOT NULL, \
           scheduled bigint NOT NULL, event_time bigint NOT NULL, due bigint NOT NULL, \
           latitude bigint NOT NULL, longitude bigint NOT NULL, altitude bigint NOT NULL, \
           ground_speed bigint NOT NULL, status bigint NOT NULL, revision bigint NOT NULL, \
           source bigint NOT NULL, parent bigint NOT NULL, sequence bigint NOT NULL); \
         CREATE INDEX callsign_idx ON {schema}.records (callsign) WHERE active AND kind=1; \
         CREATE INDEX tail_idx ON {schema}.records (tail) WHERE active AND kind=1 AND tail<>0; \
         CREATE INDEX family_idx ON {schema}.records (family) WHERE active; \
         CREATE INDEX due_idx ON {schema}.records (due) WHERE active AND kind=3; \
         CREATE INDEX event_time_idx ON {schema}.records (event_time) WHERE active;"
        ))
        .map_err(pg_error)?;
    let statement = transaction
        .prepare(&format!(
            "INSERT INTO {schema}.records ({COLUMNS}) VALUES \
         ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21)"
        ))
        .map_err(pg_error)?;
    for row in records {
        let id = i64::try_from(row.id).map_err(|_| "record id exceeds PostgreSQL bigint")?;
        transaction
            .execute(&statement, &record_parameters(row, &id))
            .map_err(pg_error)?;
    }
    transaction
        .batch_execute(&format!("ANALYZE {schema}.records"))
        .map_err(pg_error)?;
    transaction.commit().map_err(pg_error)
}

pub fn snapshot(url: &str, schema: &str) -> Result<Vec<Record>, String> {
    let schema = schema_name(schema)?;
    let mut client = connect_client(url, false)?;
    client
        .query(
            &format!("SELECT {COLUMNS} FROM {schema}.records ORDER BY id"),
            &[],
        )
        .map_err(pg_error)?
        .iter()
        .map(decode)
        .collect()
}

pub fn cleanup(url: &str, schema: &str) -> Result<(), String> {
    let quoted = schema_name(schema)?;
    let mut client = connect_client(url, false)?;
    let rows = client
        .query(
            "SELECT obj_description(oid, 'pg_namespace') FROM pg_namespace WHERE nspname=$1",
            &[&schema],
        )
        .map_err(pg_error)?;
    if rows.is_empty() {
        return Ok(());
    }
    let marker: Option<String> = rows[0].try_get(0).map_err(pg_error)?;
    if marker.as_deref() != Some(OWNERSHIP_MARKER) {
        return Err(format!(
            "refusing to remove schema {schema}: missing contention-crucible ownership marker"
        ));
    }
    client
        .batch_execute(&format!("DROP SCHEMA {quoted} CASCADE"))
        .map_err(pg_error)
}

/// Configuration of a fresh worker-equivalent connection. The native baseline
/// uses asynchronous WAL acknowledgement; PostgreSQL's flush timing and recovery
/// implementation remain different even when both acknowledge asynchronously.
pub fn configuration(url: &str, synchronous_commit: bool) -> Result<serde_json::Value, String> {
    let mut client = connect_client(url, synchronous_commit)?;
    let mut values = serde_json::Map::new();
    for setting in [
        "server_version",
        "fsync",
        "full_page_writes",
        "synchronous_commit",
        "wal_writer_delay",
        "wal_level",
        "shared_buffers",
        "max_connections",
    ] {
        let value: String = client
            .query_one("SELECT current_setting($1)", &[&setting])
            .map_err(pg_error)?
            .get(0);
        values.insert(setting.into(), value.into());
    }
    client
        .batch_execute("BEGIN ISOLATION LEVEL SERIALIZABLE")
        .map_err(pg_error)?;
    let isolation: String = client
        .query_one("SHOW transaction_isolation", &[])
        .map_err(pg_error)?
        .get(0);
    values.insert("transaction_isolation".into(), isolation.into());
    client.batch_execute("ROLLBACK").map_err(pg_error)?;
    values.insert("snapshot_established".into(), "first business query".into());
    values.insert("predeclared_write_sets".into(), false.into());
    values.insert("application_prelocks".into(), false.into());
    Ok(values.into())
}

/// Relation storage and approximate tuple retention, sampled outside timed
/// message execution. These values do not represent server resident memory.
pub fn retention(url: &str, schema: &str) -> Result<serde_json::Value, String> {
    let quoted = schema_name(schema)?;
    let relation = format!("{quoted}.records");
    let mut client = connect_client(url, false)?;
    let row = client
        .query_one(
            "SELECT pg_total_relation_size($1::text::regclass)::bigint AS total_bytes, \
             pg_table_size($1::text::regclass)::bigint AS table_bytes, \
             pg_indexes_size($1::text::regclass)::bigint AS index_bytes, \
             COALESCE(s.n_live_tup,0)::bigint AS estimated_live_tuples, \
             COALESCE(s.n_dead_tup,0)::bigint AS estimated_dead_tuples, \
             COALESCE(s.vacuum_count,0)::bigint AS vacuum_count, \
             COALESCE(s.autovacuum_count,0)::bigint AS autovacuum_count \
             FROM pg_class c LEFT JOIN pg_stat_user_tables s ON s.relid=c.oid \
             WHERE c.oid=$1::text::regclass",
            &[&relation],
        )
        .map_err(pg_error)?;
    let mut values = serde_json::Map::new();
    for key in [
        "total_bytes",
        "table_bytes",
        "index_bytes",
        "estimated_live_tuples",
        "estimated_dead_tuples",
        "vacuum_count",
        "autovacuum_count",
    ] {
        values.insert(key.into(), row.get::<_, i64>(key).into());
    }
    values.insert("tuple_counts_are_estimates".into(), true.into());
    values.insert("resident_memory_measured".into(), false.into());
    Ok(values.into())
}

impl Adapter {
    pub fn connect(url: &str, schema: &str) -> Result<Self, String> {
        Self::connect_with_durability(url, schema, false)
    }

    /// `false` acknowledges before WAL flush; `true` requests PostgreSQL's
    /// synchronous commit contract. Native runs currently use asynchronous WAL.
    pub fn connect_with_durability(
        url: &str,
        schema: &str,
        synchronous_commit: bool,
    ) -> Result<Self, String> {
        let schema = schema_name(schema)?;
        let mut client = connect_client(url, synchronous_commit)?;
        let select = format!("SELECT {COLUMNS} FROM {schema}.records");
        let read_statement = client
            .prepare(&format!("{select} WHERE id=$1"))
            .map_err(pg_error)?;
        let write_statement = client
            .prepare(&format!(
                "UPDATE {schema}.records SET active=$2,kind=$3,family=$4,pedigree=$5, \
             callsign=$6,tail=$7,origin=$8,destination=$9,scheduled=$10,event_time=$11, \
             due=$12,latitude=$13,longitude=$14,altitude=$15,ground_speed=$16,status=$17, \
             revision=$18,source=$19,parent=$20,sequence=$21 WHERE id=$1"
            ))
            .map_err(pg_error)?;
        let queries = Queries {
            candidates: client.prepare(&format!(
                "{select} WHERE active AND kind=1 \
                 AND (callsign=$1 OR ($2::bigint<>0 AND tail=$2)) \
                 AND abs(scheduled::numeric-$3::bigint::numeric)<=$4::text::numeric ORDER BY id"
            )).map_err(pg_error)?,
            family: client.prepare(&format!(
                "{select} WHERE active AND family=$1 AND kind=$2 ORDER BY id"
            )).map_err(pg_error)?,
            positions: client.prepare(&format!(
                "{select} WHERE active AND family=$1 AND pedigree=$2 AND kind=2 ORDER BY id"
            )).map_err(pg_error)?,
            due: client.prepare(&format!(
                "{select} WHERE active AND family=$1 AND kind=3 AND due<=$2 ORDER BY id"
            )).map_err(pg_error)?,
            expired: client.prepare(&format!(
                "{select} WHERE active AND family=$1 AND event_time<$2 AND kind IN (2,4,5) ORDER BY id"
            )).map_err(pg_error)?,
            all: client.prepare(&format!("{select} WHERE active ORDER BY id"))
                .map_err(pg_error)?,
        };
        Ok(Self {
            metrics: StoreMetrics::default(),
            client,
            read_statement,
            write_statement,
            queries,
            open: false,
            retry_causes: BTreeMap::new(),
            savepoints: Vec::new(),
            next_savepoint: 0,
        })
    }

    fn ensure_open(&self) -> Result<(), DbError> {
        if self.open {
            Ok(())
        } else {
            Err(DbError::Fatal("PostgreSQL transaction is closed".into()))
        }
    }

    fn classified(&mut self, stage: &str, error: ::postgres::Error) -> DbError {
        if let Some(code) = error
            .code()
            .map(|code| code.code())
            .filter(|code| retry_sqlstate(code))
        {
            *self
                .retry_causes
                .entry(format!("{stage}:{code}"))
                .or_default() += 1;
            DbError::Conflict
        } else {
            DbError::Fatal(pg_error(error))
        }
    }

    fn database_failure(&mut self, stage: &str, error: ::postgres::Error) -> DbError {
        let classified = self.classified(stage, error);
        self.fail(classified)
    }

    fn fail(&mut self, error: DbError) -> DbError {
        if self.open {
            let rollback = self.client.batch_execute("ROLLBACK");
            self.open = false;
            self.metrics.aborts += 1;
            self.savepoints.clear();
            if let Err(rollback_error) = rollback {
                return DbError::Fatal(format!("{error}; rollback also failed: {rollback_error}"));
            }
        }
        error
    }
}

impl Store for Adapter {
    fn begin(&mut self, write_slots: &[usize]) -> Result<(), DbError> {
        if self.open {
            return Err(self.fail(DbError::Fatal("transaction already open".into())));
        }
        if !write_slots.is_empty() {
            return Err(DbError::Fatal(
                "contention workload may not predeclare transaction write slots".into(),
            ));
        }
        self.client
            .batch_execute("BEGIN ISOLATION LEVEL SERIALIZABLE")
            .map_err(|error| self.classified("begin", error))?;
        self.open = true;
        self.metrics.begins += 1;
        self.savepoints.clear();
        self.next_savepoint = 0;
        // PostgreSQL fixes its snapshot at the first business query. No lock
        // query or synthetic snapshot query hides query-discovered contention.
        Ok(())
    }

    fn read(&mut self, id: usize) -> Result<Record, DbError> {
        self.ensure_open()?;
        let sql_id =
            i64::try_from(id).map_err(|_| DbError::Fatal("id exceeds PostgreSQL bigint".into()))?;
        self.metrics.reads += 1;
        match self.client.query_opt(&self.read_statement, &[&sql_id]) {
            Ok(Some(row)) => decode(&row).map_err(|error| self.fail(DbError::Fatal(error))),
            Ok(None) => Err(self.fail(DbError::Fatal(format!("missing reserved row {id}")))),
            Err(error) => Err(self.database_failure("read", error)),
        }
    }

    fn query(&mut self, query: &Query) -> Result<Vec<Record>, DbError> {
        self.ensure_open()?;
        self.metrics.queries += 1;
        let rows = match query {
            Query::Candidates {
                callsign,
                tail,
                scheduled,
                window,
            } => {
                // Numeric arithmetic avoids overflow at i64 extremes and the
                // unsigned bound exactly mirrors Query::matches' abs_diff.
                let unsigned_window = (*window as u64).to_string();
                self.client.query(
                    &self.queries.candidates,
                    &[callsign, tail, scheduled, &unsigned_window],
                )
            }
            Query::Family { family, kind } => {
                self.client.query(&self.queries.family, &[family, kind])
            }
            Query::Positions { family, pedigree } => self
                .client
                .query(&self.queries.positions, &[family, pedigree]),
            Query::Due { family, at } => self.client.query(&self.queries.due, &[family, at]),
            Query::Expired { family, before } => {
                self.client.query(&self.queries.expired, &[family, before])
            }
            Query::All => self.client.query(&self.queries.all, &[]),
        }
        .map_err(|error| self.database_failure("query", error))?;
        let records = rows
            .iter()
            .map(decode)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| self.fail(DbError::Fatal(error)))?;
        if records.iter().any(|record| !query.matches(record)) {
            return Err(self.fail(DbError::Fatal(
                "PostgreSQL query predicate differs from model".into(),
            )));
        }
        self.metrics.returned_rows += records.len() as u64;
        Ok(records)
    }

    fn write(&mut self, row: Record) -> Result<(), DbError> {
        self.ensure_open()?;
        let id = i64::try_from(row.id)
            .map_err(|_| DbError::Fatal("id exceeds PostgreSQL bigint".into()))?;
        match self
            .client
            .execute(&self.write_statement, &record_parameters(&row, &id))
        {
            Ok(1) => {
                self.metrics.writes += 1;
                Ok(())
            }
            Ok(count) => Err(self.fail(DbError::Fatal(format!(
                "write affected {count} rows instead of one"
            )))),
            Err(error) => Err(self.database_failure("write", error)),
        }
    }

    fn savepoint(&mut self) -> Result<usize, DbError> {
        self.ensure_open()?;
        let id = self.next_savepoint;
        self.next_savepoint += 1;
        self.client
            .batch_execute(&format!("SAVEPOINT contention_{id}"))
            .map_err(|error| self.database_failure("savepoint", error))?;
        self.savepoints.push(id);
        self.metrics.savepoints += 1;
        Ok(id)
    }

    fn rollback_to(&mut self, savepoint: usize) -> Result<(), DbError> {
        self.ensure_open()?;
        let Some(position) = self.savepoints.iter().position(|id| *id == savepoint) else {
            return Err(self.fail(DbError::Fatal(format!("unknown savepoint {savepoint}"))));
        };
        self.client
            .batch_execute(&format!("ROLLBACK TO SAVEPOINT contention_{savepoint}"))
            .map_err(|error| self.database_failure("rollback_to", error))?;
        self.savepoints.truncate(position + 1);
        self.metrics.savepoint_rollbacks += 1;
        Ok(())
    }

    fn commit(&mut self) -> Result<(), DbError> {
        self.ensure_open()?;
        match self.client.batch_execute("COMMIT") {
            Ok(()) => {
                self.open = false;
                self.savepoints.clear();
                self.metrics.commits += 1;
                Ok(())
            }
            // Only explicit serialization/deadlock rejection is retryable.
            // An I/O failure may have occurred after commit, so it stays fatal.
            Err(error) => Err(self.database_failure("commit", error)),
        }
    }

    fn abort(&mut self) -> Result<(), DbError> {
        if !self.open {
            return Ok(());
        }
        let result = self.client.batch_execute("ROLLBACK");
        self.open = false;
        self.savepoints.clear();
        self.metrics.aborts += 1;
        result.map_err(|error| self.classified("abort", error))
    }
}

impl Drop for Adapter {
    fn drop(&mut self) {
        let _ = self.abort();
    }
}
