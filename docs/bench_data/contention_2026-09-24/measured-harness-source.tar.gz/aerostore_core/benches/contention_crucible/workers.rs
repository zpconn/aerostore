//! Independent process workers. A sustained request generates messages locally;
//! the coordinator does not dispatch or admit individual transactions.
use super::{aerostore, model, oracle, postgres};
use crate::extended_crucible::metrics::StoreMetrics;
use crate::extended_crucible::model::{DbError, Query, Record, Store};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::io::{BufRead, Write};
use std::path::Path;
use std::sync::mpsc::{self, Receiver, TryRecvError};
use std::time::Duration;

/// Written to a private coordinator-owned file; never serialize into reports.
#[derive(Clone, Serialize, Deserialize)]
pub struct Config {
    /// Captured by the spawning coordinator before this process is started.
    pub expected_parent_pid: u32,
    pub engine: String,
    pub attachment: Option<aerostore::Attachment>,
    pub pg_url: Option<String>,
    pub schema: String,
    pub global_time_predicates: bool,
    pub worker_id: usize,
    pub workers: usize,
    pub families: usize,
    pub seed: u64,
    pub hot_percent: u32,
    pub retry_limit: u64,
    /// Minimum spacing between logical-message starts in sustained requests.
    /// Zero is unpaced; pacing waits are outside measured service latency.
    pub message_interval_us: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum Request {
    Run {
        messages: Vec<model::Message>,
        /// Only the first query of the first attempt of the first message.
        synchronise_first_query: bool,
    },
    Sustain {
        deadline_ns: u64,
        max_messages: usize,
    },
    Continue,
    Stop,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum Reply {
    Ready,
    FirstQuery {
        rows: usize,
    },
    Observation {
        receipt: oracle::Receipt,
        latency_ns: u64,
        retries: u64,
    },
    /// Cumulative counters for this worker process.
    Done {
        metrics: StoreMetrics,
        retry_causes: BTreeMap<String, u64>,
        finished_ns: u64,
        /// scenario_complete, deadline, message_cap, or stop_requested.
        stop_reason: String,
    },
    Error {
        message: String,
    },
}

pub fn monotonic_ns() -> u64 {
    let mut time = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // CLOCK_MONOTONIC has one epoch shared by all local worker processes.
    let status = unsafe { libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut time) };
    assert_eq!(status, 0, "CLOCK_MONOTONIC unavailable");
    (time.tv_sec as u64)
        .saturating_mul(1_000_000_000)
        .saturating_add(time.tv_nsec as u64)
}

fn reply(output: &mut impl Write, value: &Reply) -> Result<(), String> {
    serde_json::to_writer(&mut *output, value).map_err(|error| error.to_string())?;
    output.write_all(b"\n").map_err(|error| error.to_string())?;
    output.flush().map_err(|error| error.to_string())
}

type Inbox = Receiver<Result<Request, String>>;

fn inbox() -> Inbox {
    let (sender, receiver) = mpsc::channel();
    std::thread::spawn(move || {
        let input = std::io::stdin();
        for line in input.lock().lines() {
            let request = line
                .map_err(|error| error.to_string())
                .and_then(|line| serde_json::from_str(&line).map_err(|error| error.to_string()));
            let failed = request.is_err();
            if sender.send(request).is_err() || failed {
                break;
            }
        }
    });
    receiver
}

fn receive(input: &Inbox) -> Result<Request, String> {
    input
        .recv()
        .map_err(|_| "coordinator closed worker input".to_string())?
}

fn pacing_wake_ns(previous_start: Option<u64>, interval_us: u64, now: u64, deadline: u64) -> u64 {
    let eligible = previous_start.map_or(now, |start| {
        start.saturating_add(interval_us.saturating_mul(1000))
    });
    eligible.max(now).min(deadline)
}

trait MeasuredStore: Store {
    fn metrics(&self) -> StoreMetrics;
    fn retry_causes(&self) -> BTreeMap<String, u64>;
}
impl MeasuredStore for aerostore::Adapter<'_> {
    fn metrics(&self) -> StoreMetrics {
        self.metrics.clone()
    }
    fn retry_causes(&self) -> BTreeMap<String, u64> {
        self.retry_causes.clone()
    }
}
impl MeasuredStore for postgres::Adapter {
    fn metrics(&self) -> StoreMetrics {
        self.metrics.clone()
    }
    fn retry_causes(&self) -> BTreeMap<String, u64> {
        self.retry_causes.clone()
    }
}

/// The optional first-query barrier is solely for bounded correctness cases.
/// It runs after the actual backend query returns and before any handler write.
struct FirstQuery<'a, S, W> {
    store: &'a mut S,
    input: &'a Inbox,
    output: &'a mut W,
    armed: bool,
}
impl<S: Store, W: Write> Store for FirstQuery<'_, S, W> {
    fn begin(&mut self, declared: &[usize]) -> Result<(), DbError> {
        self.store.begin(declared)
    }
    fn read(&mut self, id: usize) -> Result<Record, DbError> {
        self.store.read(id)
    }
    fn query(&mut self, query: &Query) -> Result<Vec<Record>, DbError> {
        let result = self.store.query(query);
        if !self.armed {
            return result;
        }
        self.armed = false;
        // Retrying before all workers reach this cutpoint would silently weaken
        // the forced-overlap case. Fail that case instead; retries after a
        // successful barrier release proceed without another barrier.
        let rows = result.map_err(|error| {
            DbError::Fatal(format!(
                "synchronized first query failed before barrier: {error}"
            ))
        })?;
        reply(self.output, &Reply::FirstQuery { rows: rows.len() }).map_err(DbError::Fatal)?;
        match receive(self.input).map_err(DbError::Fatal)? {
            Request::Continue => Ok(rows),
            _ => Err(DbError::Fatal(
                "expected Continue at first-query barrier".into(),
            )),
        }
    }
    fn write(&mut self, row: Record) -> Result<(), DbError> {
        self.store.write(row)
    }
    fn savepoint(&mut self) -> Result<usize, DbError> {
        self.store.savepoint()
    }
    fn rollback_to(&mut self, savepoint: usize) -> Result<(), DbError> {
        self.store.rollback_to(savepoint)
    }
    fn commit(&mut self) -> Result<(), DbError> {
        self.store.commit()
    }
    fn abort(&mut self) -> Result<(), DbError> {
        self.store.abort()
    }
}

fn execute(
    store: &mut impl MeasuredStore,
    input: &Inbox,
    output: &mut impl Write,
    message: model::Message,
    barrier: bool,
    retry_limit: u64,
) -> Result<u64, String> {
    let first_started = monotonic_ns();
    let mut retries = 0;
    loop {
        let started = monotonic_ns();
        let mut observed = FirstQuery {
            store,
            input,
            output,
            armed: barrier && retries == 0,
        };
        let result = model::execute_attempt(&mut observed, &message);
        let finished = monotonic_ns();
        match result {
            Ok(body) => {
                if finished <= started {
                    return Err("non-increasing successful attempt clock".into());
                }
                return reply(
                    output,
                    &Reply::Observation {
                        receipt: oracle::Receipt {
                            message,
                            started,
                            finished,
                            body,
                        },
                        latency_ns: finished - first_started,
                        retries,
                    },
                )
                .map(|()| first_started);
            }
            Err(DbError::Conflict) if retries < retry_limit => {
                store
                    .abort()
                    .map_err(|error| format!("retry cleanup failed: {error}"))?;
                retries += 1;
                std::thread::sleep(Duration::from_micros(
                    retries.saturating_mul(50).min(10_000),
                ));
            }
            Err(error) => {
                let cleanup = store.abort();
                return Err(format!(
                    "message {} after {retries} retries: {error}; cleanup={cleanup:?}",
                    message.id
                ));
            }
        }
    }
}

fn worker_loop(config: &Config, store: &mut impl MeasuredStore) -> Result<(), String> {
    let input = inbox();
    let stdout = std::io::stdout();
    let mut output = stdout.lock();
    reply(&mut output, &Reply::Ready)?;
    let mut local_sequence = 0_u64;
    let mut previous_sustained_start = None;
    loop {
        let mut stop = false;
        let mut stop_reason;
        match receive(&input)? {
            Request::Run {
                messages,
                synchronise_first_query,
            } => {
                stop_reason = "scenario_complete";
                for (index, message) in messages.into_iter().enumerate() {
                    execute(
                        store,
                        &input,
                        &mut output,
                        message,
                        synchronise_first_query && index == 0,
                        config.retry_limit,
                    )?;
                }
            }
            Request::Sustain {
                deadline_ns,
                max_messages,
            } => {
                stop_reason = "message_cap";
                for _ in 0..max_messages {
                    match input.try_recv() {
                        Ok(Ok(Request::Stop)) => {
                            stop = true;
                            stop_reason = "stop_requested";
                            break;
                        }
                        Ok(Ok(_)) => return Err("unexpected command during sustained run".into()),
                        Ok(Err(error)) => return Err(error),
                        Err(TryRecvError::Disconnected) => {
                            return Err("coordinator closed worker input".into())
                        }
                        Err(TryRecvError::Empty) => (),
                    }
                    if monotonic_ns() >= deadline_ns {
                        stop_reason = "deadline";
                        break;
                    }
                    let now = monotonic_ns();
                    let wake = pacing_wake_ns(
                        previous_sustained_start,
                        config.message_interval_us,
                        now,
                        deadline_ns,
                    );
                    if wake > now {
                        match input.recv_timeout(Duration::from_nanos(wake - now)) {
                            Ok(Ok(Request::Stop)) => {
                                stop = true;
                                stop_reason = "stop_requested";
                                break;
                            }
                            Ok(Ok(_)) => {
                                return Err("unexpected command during message pacing".into())
                            }
                            Ok(Err(error)) => return Err(error),
                            Err(mpsc::RecvTimeoutError::Disconnected) => {
                                return Err("coordinator closed worker input".into())
                            }
                            Err(mpsc::RecvTimeoutError::Timeout) => (),
                        }
                    }
                    if monotonic_ns() >= deadline_ns {
                        stop_reason = "deadline";
                        break;
                    }
                    let sequence = local_sequence
                        .checked_mul(config.workers as u64)
                        .and_then(|value| value.checked_add(config.worker_id as u64))
                        .ok_or("worker sequence overflow")?;
                    let message = model::sustained_message(
                        sequence,
                        config.worker_id,
                        config.workers,
                        config.families,
                        config.seed,
                        config.hot_percent,
                    );
                    let message_started = execute(
                        store,
                        &input,
                        &mut output,
                        message,
                        false,
                        config.retry_limit,
                    )?;
                    previous_sustained_start = Some(message_started);
                    local_sequence = local_sequence
                        .checked_add(1)
                        .ok_or("worker sequence overflow")?;
                }
            }
            Request::Stop => {
                store.abort().map_err(|error| error.to_string())?;
                return Ok(());
            }
            Request::Continue => return Err("Continue outside first-query barrier".into()),
        }
        reply(
            &mut output,
            &Reply::Done {
                metrics: store.metrics(),
                retry_causes: store.retry_causes(),
                finished_ns: monotonic_ns(),
                stop_reason: stop_reason.into(),
            },
        )?;
        if stop {
            store.abort().map_err(|error| error.to_string())?;
            return Ok(());
        }
    }
}

fn worker_inner(config_path: &Path) -> Result<(), String> {
    let config: Config =
        serde_json::from_slice(&std::fs::read(config_path).map_err(|error| error.to_string())?)
            .map_err(|error| error.to_string())?;
    unsafe {
        // A coordinator-supplied PID detects an exit before the worker's first
        // instruction, including adoption by a subreaper whose PID is not 1.
        // The check after registration closes the PR_SET_PDEATHSIG race.
        if config.expected_parent_pid == 0
            || libc::getppid() as u32 != config.expected_parent_pid
            || libc::prctl(libc::PR_SET_PDEATHSIG, libc::SIGKILL) != 0
            || libc::getppid() as u32 != config.expected_parent_pid
        {
            return Err("failed to establish worker parent lifetime".into());
        }
    }
    if config.workers == 0
        || config.worker_id >= config.workers
        || config.families == 0
        || config.hot_percent > 100
    {
        return Err("invalid worker count, identity count, or hot-identity percentage".into());
    }
    match config.engine.as_str() {
        "aerostore" => {
            let shared = aerostore::Shared::attach(
                config
                    .attachment
                    .as_ref()
                    .ok_or("missing arena attachment")?,
            )?;
            let mut adapter = aerostore::Adapter::new(&shared, config.global_time_predicates);
            worker_loop(&config, &mut adapter)
        }
        "postgres" => worker_loop(
            &config,
            &mut postgres::Adapter::connect(
                config
                    .pg_url
                    .as_deref()
                    .ok_or("missing PostgreSQL connection")?,
                &config.schema,
            )?,
        ),
        _ => Err("invalid worker engine".into()),
    }
}

pub fn worker_main(config_path: &Path) -> Result<(), String> {
    let result = worker_inner(config_path);
    if let Err(message) = &result {
        // Configuration/attachment failures and runtime failures share one wire
        // error shape; the process still exits unsuccessfully via the runner.
        let _ = reply(
            &mut std::io::stdout().lock(),
            &Reply::Error {
                message: message.clone(),
            },
        );
    }
    result
}

#[cfg(test)]
mod tests {
    use super::pacing_wake_ns;

    #[test]
    fn pacing_accounts_for_execution_time_and_never_extends_deadline() {
        assert_eq!(pacing_wake_ns(None, 1000, 500, 10_000), 500);
        assert_eq!(pacing_wake_ns(Some(1000), 0, 5000, 10_000), 5000);
        // A 10us interval after a start at 1us leaves 6us to wait at t=5us.
        assert_eq!(pacing_wake_ns(Some(1000), 10, 5000, 50_000), 11_000);
        // Slow execution already consumed the interval: no additive sleep.
        assert_eq!(pacing_wake_ns(Some(1000), 10, 20_000, 50_000), 20_000);
        // No paced message may be scheduled beyond the common deadline.
        assert_eq!(pacing_wake_ns(Some(1000), 10, 5000, 9000), 9000);
        assert_eq!(
            pacing_wake_ns(Some(u64::MAX - 10), u64::MAX, 5000, 9000),
            9000
        );
    }
}
