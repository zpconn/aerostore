//! Runner supervision tests; no benchmark workload or database is started.
#![cfg(target_os = "linux")]
#![allow(dead_code, unused_imports)]

#[path = "../benches/contention_crucible/mod.rs"]
mod contention_crucible;
#[path = "../benches/extended_crucible/mod.rs"]
mod extended_crucible;
