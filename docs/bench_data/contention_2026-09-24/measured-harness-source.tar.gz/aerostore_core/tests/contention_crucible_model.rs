//! The contention oracle is deliberately tested against corrupt histories,
//! not merely successful replay of its own preferred execution order.
#![allow(dead_code)]
#[path = "../benches/extended_crucible/model.rs"]
pub mod shared_model;
mod extended_crucible {
    pub use crate::shared_model as model;
}
#[path = "../benches/contention_crucible/model.rs"]
mod model;
#[path = "../benches/contention_crucible/oracle.rs"]
mod oracle;

use model::{Operation, RecordedQuery};
use oracle::{Receipt, Status};
use shared_model::Record;
use std::collections::BTreeMap;

fn history(scenario: &model::Scenario, reverse: bool) -> (Vec<Receipt>, Vec<Record>) {
    let mut rows: BTreeMap<_, _> = scenario.initial.iter().map(|row| (row.id, *row)).collect();
    let messages: Vec<_> = if reverse {
        scenario.messages.iter().rev().collect()
    } else {
        scenario.messages.iter().collect()
    };
    let receipts = messages
        .into_iter()
        .enumerate()
        .map(|(index, message)| Receipt {
            message: message.clone(),
            started: index as u64 + 1,
            finished: 1000 - index as u64, // Response order deliberately opposes serialization.
            body: model::serial_apply(&mut rows, message).unwrap(),
        })
        .collect();
    (receipts, rows.values().copied().collect())
}

#[test]
fn every_scenario_accepts_both_serial_orders_with_reversed_response_order() {
    for scenario in model::scenarios(71) {
        for reverse in [false, true] {
            let (receipts, final_rows) = history(&scenario, reverse);
            let result = oracle::check(&scenario.initial, &receipts, &final_rows, 10000);
            assert_eq!(
                result.status,
                Status::Valid,
                "{}: {}",
                scenario.name,
                result.detail
            );
            let mut observed_ids = result.order.clone();
            let mut expected_ids: Vec<_> =
                receipts.iter().map(|receipt| receipt.message.id).collect();
            observed_ids.sort_unstable();
            expected_ids.sort_unstable();
            assert_eq!(observed_ids, expected_ids);
            model::validate_snapshot(&final_rows).unwrap();
        }
    }
}

#[test]
fn competing_creators_match_the_winner_instead_of_their_allocation_hint() {
    let scenario = model::scenarios(19).remove(0);
    let (receipts, rows) = history(&scenario, true);
    let winning_family = scenario.messages.last().unwrap().allocation_family as i64;
    assert!(receipts
        .iter()
        .all(|receipt| receipt.body.outcome.family == Some(winning_family)));
    assert_eq!(
        rows.iter()
            .filter(|row| row.active && row.kind == shared_model::FLIGHT)
            .count(),
        7
    );
    assert!(rows
        .iter()
        .filter(|row| row.active)
        .all(|row| row.family == winning_family));
    assert!(receipts[0].body.operations.iter().any(|op| matches!(op,
        Operation::Query { query: RecordedQuery::Candidates { .. }, rows } if rows.is_empty())));
}

#[test]
fn oracle_rejects_two_creators_that_both_commit_after_empty_searches() {
    let scenario = model::scenarios(1).remove(0);
    let mut final_rows: BTreeMap<_, _> =
        scenario.initial.iter().map(|row| (row.id, *row)).collect();
    let mut receipts = Vec::new();
    for message in &scenario.messages[..2] {
        let mut isolated: BTreeMap<_, _> =
            scenario.initial.iter().map(|row| (row.id, *row)).collect();
        let body = model::serial_apply(&mut isolated, message).unwrap();
        for (id, row) in isolated {
            if row != final_rows[&id] && row.active {
                final_rows.insert(id, row);
            }
        }
        receipts.push(Receipt {
            message: message.clone(),
            started: 1,
            finished: 10,
            body,
        });
    }
    let result = oracle::check(
        &scenario.initial,
        &receipts,
        &final_rows.values().copied().collect::<Vec<_>>(),
        100,
    );
    assert_eq!(result.status, Status::Invalid);
}

#[test]
fn oracle_rejects_incomplete_candidate_results_even_when_final_state_matches() {
    let scenario = model::scenarios(2).remove(1);
    let (mut receipts, rows) = history(&scenario, false);
    let query = receipts[0]
        .body
        .operations
        .iter_mut()
        .find_map(|operation| match operation {
            Operation::Query {
                query: RecordedQuery::Candidates { .. },
                rows,
            } if !rows.is_empty() => Some(rows),
            _ => None,
        })
        .unwrap();
    query.pop();
    assert_eq!(
        oracle::check(&scenario.initial, &receipts, &rows, 10000).status,
        Status::Invalid
    );
}

#[test]
fn oracle_rejects_missing_write_wrong_output_and_lost_final_effect() {
    let scenario = model::scenarios(3).remove(1);
    let (receipts, rows) = history(&scenario, false);
    let mut missing = receipts.clone();
    let index = missing[0]
        .body
        .operations
        .iter()
        .position(|operation| matches!(operation, Operation::Write { .. }))
        .unwrap();
    missing[0].body.operations.remove(index);
    assert_eq!(
        oracle::check(&scenario.initial, &missing, &rows, 10000).status,
        Status::Invalid
    );
    let mut output = receipts.clone();
    output[0].body.outcome.outputs[0].latitude += 1;
    assert_eq!(
        oracle::check(&scenario.initial, &output, &rows, 10000).status,
        Status::Invalid
    );
    let mut lost = rows.clone();
    let index = lost
        .iter()
        .position(|row| *row != scenario.initial[row.id])
        .unwrap();
    lost[index] = scenario.initial[lost[index].id];
    assert_eq!(
        oracle::check(&scenario.initial, &receipts, &lost, 10000).status,
        Status::Invalid
    );
}

#[test]
fn nonoverlapping_intervals_are_binding_but_response_order_is_not() {
    let mut scenario = model::scenarios(4).remove(0);
    scenario.messages.truncate(2);
    let (mut receipts, rows) = history(&scenario, false);
    assert_eq!(
        oracle::check(&scenario.initial, &receipts, &rows, 100).status,
        Status::Valid
    );
    receipts[1].started = 1;
    receipts[1].finished = 10;
    receipts[0].started = 11;
    receipts[0].finished = 20;
    assert_eq!(
        oracle::check(&scenario.initial, &receipts, &rows, 100).status,
        Status::Invalid
    );
}

#[test]
fn insufficient_search_budget_is_inconclusive_and_never_passes() {
    let scenario = model::scenarios(5).remove(1);
    let (receipts, rows) = history(&scenario, false);
    assert_eq!(
        oracle::check(&scenario.initial, &receipts, &rows, 0).status,
        Status::Inconclusive
    );
    assert_eq!(
        oracle::check(&scenario.initial, &receipts, &rows, 1).status,
        Status::Inconclusive
    );
}

#[test]
fn fixed_seed_stream_has_mixed_kinds_hot_identity_and_real_key_changes() {
    let initial = model::sustained_initial(4, 99);
    let mut rows: BTreeMap<_, _> = initial.iter().map(|row| (row.id, *row)).collect();
    let mut renamed = false;
    let mut kinds = BTreeMap::<String, usize>::new();
    let mut receipts = Vec::new();
    for sequence in 0..128 {
        let message = model::sustained_message(sequence, sequence as usize % 4, 4, 4, 99, 100);
        assert_eq!(message.tail, 10000);
        *kinds
            .entry(format!("{:?}", std::mem::discriminant(&message.kind)))
            .or_default() += 1;
        let body = model::serial_apply(&mut rows, &message).unwrap();
        renamed |= rows
            .values()
            .any(|row| row.active && row.kind == shared_model::FLIGHT && row.callsign >= 1000);
        receipts.push(Receipt {
            message,
            started: sequence * 2 + 1,
            finished: sequence * 2 + 2,
            body,
        });
    }
    assert!(
        renamed,
        "sustained rename must actually change indexed keys"
    );
    assert_eq!(kinds.len(), 5);
    model::validate_snapshot(&rows.values().copied().collect::<Vec<_>>()).unwrap();
    assert_eq!(
        oracle::check(
            &initial,
            &receipts,
            &rows.values().copied().collect::<Vec<_>>(),
            128
        )
        .status,
        Status::Valid
    );
}

#[test]
fn provenance_output_never_contains_an_excluded_source() {
    let scenario = model::scenarios(33).remove(1);
    let (receipts, rows) = history(&scenario, false);
    assert!(receipts
        .iter()
        .flat_map(|receipt| &receipt.body.outcome.outputs)
        .all(|output| output.source & !output.pedigree == 0));
    assert!(rows
        .iter()
        .filter(|row| row.active && row.kind != shared_model::DEDUP)
        .all(|row| row.source & !row.pedigree == 0));
}

#[test]
fn independent_structure_checker_rejects_duplicate_identity_and_changed_family_evidence() {
    let scenario = model::scenarios(77).remove(0);
    let mut combined: BTreeMap<_, _> = scenario.initial.iter().map(|row| (row.id, *row)).collect();
    for message in &scenario.messages[..2] {
        let mut isolated: BTreeMap<_, _> =
            scenario.initial.iter().map(|row| (row.id, *row)).collect();
        model::serial_apply(&mut isolated, message).unwrap();
        combined.extend(isolated.into_iter().filter(|(_, row)| row.active));
    }
    let rows: Vec<_> = combined.values().copied().collect();
    shared_model::validate_snapshot(&rows).unwrap();
    assert!(model::validate_snapshot(&rows)
        .unwrap_err()
        .contains("independent families"));
    let mut rows = model::sustained_initial(4, 77);
    model::validate_snapshot(&rows).unwrap();
    rows.iter_mut()
        .find(|row| row.active && row.kind == shared_model::FLIGHT && row.pedigree == 3)
        .unwrap()
        .tail += 100;
    assert!(model::validate_snapshot(&rows)
        .unwrap_err()
        .contains("inconsistent immutable identity"));
}

#[test]
fn conflict_with_failed_cleanup_is_fatal_and_cannot_be_retried() {
    use shared_model::{DbError, Query, Store};
    struct FailedCleanup {
        at_commit: bool,
    }
    impl Store for FailedCleanup {
        fn begin(&mut self, slots: &[usize]) -> Result<(), DbError> {
            assert!(slots.is_empty());
            Ok(())
        }
        fn read(&mut self, _: usize) -> Result<Record, DbError> {
            unreachable!()
        }
        fn query(&mut self, _: &Query) -> Result<Vec<Record>, DbError> {
            if self.at_commit {
                Ok(vec![])
            } else {
                Err(DbError::Conflict)
            }
        }
        fn write(&mut self, _: Record) -> Result<(), DbError> {
            unreachable!()
        }
        fn savepoint(&mut self) -> Result<usize, DbError> {
            unreachable!()
        }
        fn rollback_to(&mut self, _: usize) -> Result<(), DbError> {
            unreachable!()
        }
        fn commit(&mut self) -> Result<(), DbError> {
            Err(DbError::Conflict)
        }
        fn abort(&mut self) -> Result<(), DbError> {
            Err(DbError::Fatal("injected cleanup failure".into()))
        }
    }
    // Empty maintenance returns before any physical reads/writes, allowing both
    // the handler-error and commit-error cleanup paths to be exercised.
    let mut message = model::scenarios(1).remove(0).messages.remove(0);
    message.kind = model::MessageKind::Project { at: 0 };
    for at_commit in [false, true] {
        let error = model::execute_attempt(&mut FailedCleanup { at_commit }, &message).unwrap_err();
        assert!(
            matches!(error, DbError::Fatal(detail) if detail.contains("abort failed") && detail.contains("injected cleanup failure"))
        );
    }
}
