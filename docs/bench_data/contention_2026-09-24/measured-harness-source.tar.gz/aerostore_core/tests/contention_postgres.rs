//! PostgreSQL adapter contract probes. Live tests require a disposable local
//! PostgreSQL URL in AEROSTORE_CONTENTION_PG_URL and explicit --ignored.
#![allow(dead_code)]

#[path = "../benches/extended_crucible/metrics.rs"]
pub mod existing_metrics;
#[path = "../benches/extended_crucible/model.rs"]
pub mod existing_model;
mod extended_crucible {
    pub use super::existing_metrics as metrics;
    pub use super::existing_model as model;
}
#[path = "../benches/contention_crucible/postgres.rs"]
mod adapter;

use existing_model::{DbError, Query, Record, Store, FLIGHT};

#[test]
#[ignore = "requires AEROSTORE_CONTENTION_PG_URL pointing to disposable PostgreSQL"]
fn serializable_queries_discover_writes_without_predeclaring_them() {
    let url = std::env::var("AEROSTORE_CONTENTION_PG_URL").expect("disposable PostgreSQL URL");
    let schema = format!("contention_contract_{}", std::process::id());
    let records = vec![
        Record {
            id: 0,
            ..Record::default()
        },
        Record {
            id: 1,
            ..Record::default()
        },
    ];
    adapter::initialize(&url, &schema, &records).unwrap();
    let result = std::panic::catch_unwind(|| {
        let mut a = adapter::Adapter::connect(&url, &schema).unwrap();
        let mut b = adapter::Adapter::connect(&url, &schema).unwrap();
        assert!(matches!(a.begin(&[0]), Err(DbError::Fatal(_))));
        a.begin(&[]).unwrap();
        b.begin(&[]).unwrap();
        let predicate = Query::Candidates {
            callsign: 42,
            tail: 0,
            scheduled: 0,
            window: 1,
        };
        assert!(a.query(&predicate).unwrap().is_empty());
        assert!(b.query(&predicate).unwrap().is_empty());
        let create = |id| Record {
            id,
            active: true,
            kind: FLIGHT,
            callsign: 42,
            ..Record::default()
        };
        a.write(create(0)).unwrap();
        let b_write = b.write(create(1));
        let a_commit = a.commit();
        let b_commit = b_write.and_then(|()| b.commit());
        let commits = usize::from(a_commit.is_ok()) + usize::from(b_commit.is_ok());
        assert_eq!(
            commits, 1,
            "two overlapping empty searches must not both create"
        );
        for rejected in [a_commit, b_commit].into_iter().filter_map(Result::err) {
            assert_eq!(rejected, DbError::Conflict);
        }
        let retry_count: u64 = a.retry_causes.values().chain(b.retry_causes.values()).sum();
        assert_eq!(retry_count, 1);
        assert!(a
            .retry_causes
            .keys()
            .chain(b.retry_causes.keys())
            .all(|key| key.ends_with(":40001")));
        assert_eq!(
            adapter::snapshot(&url, &schema)
                .unwrap()
                .into_iter()
                .filter(|row| predicate.matches(row))
                .count(),
            1
        );
        let storage = adapter::retention(&url, &schema).unwrap();
        assert!(storage["total_bytes"].as_i64().unwrap() > 0);
        assert_eq!(storage["resident_memory_measured"], false);
        assert_eq!(
            adapter::configuration(&url, false).unwrap()["synchronous_commit"],
            "off"
        );
        assert_eq!(
            adapter::configuration(&url, true).unwrap()["synchronous_commit"],
            "on"
        );
    });
    adapter::cleanup(&url, &schema).unwrap();
    if let Err(payload) = result {
        std::panic::resume_unwind(payload);
    }
}

#[test]
#[ignore = "requires AEROSTORE_CONTENTION_PG_URL pointing to disposable PostgreSQL"]
fn scratch_schema_cleanup_refuses_unowned_schemas() {
    let url = std::env::var("AEROSTORE_CONTENTION_PG_URL").expect("disposable PostgreSQL URL");
    let schema = format!("contention_unowned_{}", std::process::id());
    let mut client = postgres::Client::connect(&url, postgres::NoTls).unwrap();
    client
        .batch_execute(&format!("CREATE SCHEMA {schema}"))
        .unwrap();
    let result = adapter::cleanup(&url, &schema);
    // This test created the unmarked schema itself; clean it through that same
    // known ownership rather than bypassing the benchmark cleanup check.
    client
        .batch_execute(&format!("DROP SCHEMA {schema}"))
        .unwrap();
    assert!(result.unwrap_err().contains("ownership marker"));
}
