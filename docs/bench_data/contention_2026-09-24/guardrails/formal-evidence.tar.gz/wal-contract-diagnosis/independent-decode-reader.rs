use serde::{Deserialize, Serialize};
#[derive(Deserialize,Serialize)]
struct TclLikeRow { exists:u8, flight:[u8;12], altitude:i32, gs:u16 }
fn main() {
 let path=std::env::args().nth(1).unwrap();
 let records=aerostore_core::read_wal_file(&path).unwrap();
 let mut decoded=Vec::new();
 for commit in records {
  let mut writes=Vec::new();
  for write in commit.writes {
   let value:TclLikeRow=bincode::deserialize(&write.value_payload).unwrap();
   let logical=aerostore_core::wal_delta::deserialize_wal_record(&write.wal_record_payload).unwrap();
   let logical_value=match &logical {
    aerostore_core::wal_delta::WalRecord::UpdateFull { payload, .. }=>serde_json::to_value(bincode::deserialize::<TclLikeRow>(payload).unwrap()).unwrap(),
    _=>panic!("expected full baseline after writer restart")
   };
   let flight=String::from_utf8_lossy(&value.flight).trim_end_matches('\0').to_string();
   writes.push(serde_json::json!({"row_id":write.row_id,"base_offset":write.base_offset,"new_offset":write.new_offset,
    "flight":flight,"full_row":value,"logical_record":logical,"logical_full_row":logical_value}));
  }
  decoded.push(serde_json::json!({"version":commit.version,"txid":commit.txid,"writes":writes}));
 }
 println!("{}",serde_json::to_string_pretty(&decoded).unwrap());
}
