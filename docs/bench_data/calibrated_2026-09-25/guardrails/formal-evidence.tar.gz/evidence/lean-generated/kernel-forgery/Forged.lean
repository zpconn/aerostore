import Lean
set_option debug.skipKernelTC true
open Lean Elab Command
elab "injectFalse" : command => do
  liftCoreM <| addDecl (.thmDecl {
    name := `forgedFalse
    levelParams := []
    type := mkConst ``False
    value := mkConst ``True.intro })
injectFalse
#print axioms forgedFalse
