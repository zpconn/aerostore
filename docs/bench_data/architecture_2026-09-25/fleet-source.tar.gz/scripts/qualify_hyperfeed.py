#!/usr/bin/env python3
"""Collect exploratory HyperFeed capacity evidence without promoting an engine.

Use a built hyperfeed_contention_crucible binary and an explicitly managed local
PostgreSQL server. Credentials are read only from --pg-url-env. Each matrix cell
is a fresh benchmark process; every seed, failure, complete report and log is
retained. Source hashes include dirty Rust, workload, proof and gate inputs.

--workload lifecycle preserves the concentrated generation stress corpus.
--workload fleet requires --hot-percent 0 and at least 16 configured identities;
it starts from 16 warmup rounds and interleaves live generations across identities.

First use --evidence full to produce a correctness companion. A metrics campaign
may name that campaign's campaign.json via --correctness-report. Companions must
have identical source/binary fingerprints and exact engine/configuration/corpus
coverage. A companion does NOT verify the metrics run's unrecorded history.

Public helpers assess_trial(), build_gate(), snapshot_sources(), and run_process()
are deliberately testable without databases. Tested capacities are lower bounds;
their ratio alone cannot establish a 10x claim. Even a synthetic capacity bound
does not qualify real HyperFeed compatibility, recovery, or MMHF availability.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import platform
import re
import shlex
import signal
import subprocess
import sys
import tempfile
import time
import uuid
from urllib.parse import urlsplit, unquote

ROOT = Path(__file__).resolve().parents[1]
FORMAT = "hyperfeed-qualification-v1"
ENGINES = ("aerostore", "service-unix", "service-tcp", "postgres")
CORPUS_FIELDS = ("workload", "families", "hot_percent", "seed", "arrival_rate", "seconds")
MATCH_FIELDS = CORPUS_FIELDS + ("engine", "workers", "pg_write_mode", "rpc_delay_us", "global_time_predicates", "shm_mib", "max_backlog", "max_messages", "message_interval_us")
EFFECT_FIELDS = ("created_views", "updated_views", "outputs", "claimed_events", "cancelled_events", "rescheduled_events", "expired_records", "expired_families")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def snapshot_sources(root: Path = ROOT) -> dict:
    """Hash working bytes, including untracked source; never substitute HEAD."""
    files = {}
    for name in ("Cargo.toml", "Cargo.lock", "rust-toolchain", "rust-toolchain.toml"):
        path = root / name
        if path.is_file():
            files[name] = sha256(path)
    for name in ("aerostore_core", "aerostore_verified", "aerostore_macros", "aerostore_tcl", "verification", "scripts", ".cargo"):
        directory = root / name
        if not directory.exists():
            continue
        for current, dirs, names in os.walk(directory):
            dirs[:] = sorted(d for d in dirs if d not in {"target", ".git", ".lake", "__pycache__", ".venv"})
            for filename in sorted(names):
                path = Path(current) / filename
                if path.suffix in {".rs", ".toml", ".lock", ".lean", ".tla", ".cfg", ".json", ".py", ".sh"}:
                    files[str(path.relative_to(root))] = sha256(path)
    encoded = json.dumps(files, sort_keys=True, separators=(",", ":")).encode()
    return {"sha256": hashlib.sha256(encoded).hexdigest(), "files": files}


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def finite_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def key(config: dict) -> tuple:
    return tuple(config.get(field) for field in MATCH_FIELDS)


def compatible_companion(companion: dict | None, source: dict, binary_sha: str) -> bool:
    return bool(companion and companion.get("format") == FORMAT
                and companion.get("completed") is True and companion.get("source_stable") is True
                and companion.get("source_before") == source == companion.get("source_after")
                and companion.get("binary_before_sha256") == binary_sha == companion.get("binary_after_sha256"))


def collect_outcomes(run: dict) -> dict:
    totals = {}
    for kind, statistics in run.get("per_kind", {}).items():
        if not isinstance(statistics, dict) or not isinstance(statistics.get("outcomes"), dict):
            raise ValueError(f"missing outcome counts for {kind}")
        for name, count in statistics["outcomes"].items():
            if type(count) is not int or count < 0:
                raise ValueError("invalid outcome counter")
            totals[name] = totals.get(name, 0) + count
    return totals


def lifecycle_kind_counts(offered: int) -> dict:
    kinds = ("plan", "position", "plan", "position", "plan", "position", "global_projection", "global_reschedule", "arrival", "arrival", "arrival", "expire_family", "global_housekeeping", "expire_family", "global_cancel", "global_housekeeping")
    counts = {}
    for step, kind in enumerate(kinds):
        count = offered // 16 + int(step < offered % 16)
        if count:
            counts[kind] = counts.get(kind, 0) + count
    return counts


def expected_kind_counts(config: dict, offered: int) -> dict:
    """Independently enumerate the declared fleet schedule, without Rust output.

    Warmup is sixteen complete identity rounds. Each timed round visits every
    identity in a triangularly rotated order; identity age selects its phase.
    This count depends only on the offered corpus, never on worker completion.
    """
    if config.get("workload") == "lifecycle":
        return lifecycle_kind_counts(offered)
    if config.get("workload") != "fleet":
        raise ValueError("unsupported capacity workload")
    families = config["families"]
    if families < 16 or config["hot_percent"] != 0:
        raise ValueError("fleet requires at least 16 identities and hot-percent=0")
    phases = ("plan", "position", "plan", "position", "plan", "position", "global_projection", "global_reschedule", "arrival", "arrival", "arrival", "expire_family", "global_housekeeping", "expire_family", "global_cancel", "global_housekeeping")
    counts = {}
    remaining = offered
    current_round = 16
    while remaining:
        rotation = current_round * (current_round + 1) // 2 % families
        for slot in range(min(remaining, families)):
            identity = (slot + rotation) % families
            phase = (current_round + identity % 16 + config["seed"] % 16) % 16
            kind = phases[phase]
            counts[kind] = counts.get(kind, 0) + 1
        remaining -= min(remaining, families)
        current_round += 1
    return counts


def assess_trial(trial: dict, policy: dict, companion_keys: set[tuple] = frozenset()) -> dict:
    """Fail closed on incomplete input coverage, timing, errors or bad histories.

    A performance failure is separate from invalid evidence: only reproducible
    latency/drain-rate failures can establish a tested saturation upper bound.
    """
    result = {"execution_valid": False, "performance_passed": False,
              "correctness_companion_verified": False, "history_verified": False,
              "qualified_capacity_trial": False, "capacity_failure": False, "reasons": []}
    reasons = result["reasons"]
    config = trial.get("config", {})
    report = trial.get("report", {})
    if trial.get("exit_code") != 0 or trial.get("timed_out") or trial.get("error"):
        reasons.append("process failed, timed out, or lacked a readable report")
    if not trial.get("source_stable", False):
        reasons.append("source or binary changed during trial")
    if report.get("completed") is not True or report.get("passed") is not True:
        reasons.append("benchmark did not complete successfully")
    actual = report.get("config", {})
    if actual.get("mode") != "sustained" or any(actual.get(field) != config.get(field) for field in MATCH_FIELDS + ("evidence",)):
        reasons.append("reported configuration differs from offered corpus/configuration")
    if config.get("workload") not in {"lifecycle", "fleet"} or not finite_number(config.get("arrival_rate")) or config.get("arrival_rate", 0) <= 0:
        reasons.append("capacity requires a fixed lifecycle/fleet corpus with positive offered arrivals")
    runs = report.get("runs", [])
    if not isinstance(runs, list) or len(runs) != 1 or not isinstance(runs[0], dict):
        reasons.append("expected exactly one sustained run")
        return result
    run = runs[0]
    if run.get("engine") != config.get("engine") or run.get("scenario") != "sustained-mixed":
        reasons.append("wrong engine or sustained scenario")
    if run.get("passed") is not True or run.get("execution_completed") is not True or run.get("error"):
        reasons.append("run failed correctness, progress, or execution")
    expected = config.get("arrival_rate", 0) * config.get("seconds", 0)
    workers = config.get("workers", 0)
    counts = run.get("completed_by_worker", [])
    expected_counts = [(expected - 1 - worker) // workers + 1 if expected > worker else 0 for worker in range(workers)] if type(workers) is int and workers > 0 else []
    if (run.get("arrival_mode") != "independent_fixed_corpus" or run.get("offered_messages") != expected
            or run.get("completed_messages") != expected or counts != expected_counts or not expected_counts or min(expected_counts) <= 0):
        reasons.append("offered corpus was omitted, duplicated, truncated, or changed")
    if (run.get("admission_seconds") != config.get("seconds")
            or run.get("offered_rate_per_second") != config.get("arrival_rate")
            or run.get("requested_duration_reached") is not True or run.get("worker_message_cap_reached") is not False
            or not finite_number(run.get("elapsed_seconds")) or run.get("elapsed_seconds", 0) < config.get("seconds", 0)):
        reasons.append("full admission duration was not observed")
    stops = run.get("worker_stops", [])
    if len(stops) != workers or any(s.get("stop_reason") != "arrival_corpus_drained" for s in stops):
        reasons.append("a worker did not drain the fixed corpus")
    if run.get("invariants", {}).get("passed") is not True:
        reasons.append("final structural invariants failed or missing")
    if run.get("store_metrics", {}).get("commits") != expected:
        reasons.append("commit count differs from complete offered corpus")
    full = (config.get("evidence") == "full" and run.get("history_checked") is True
            and run.get("correctness_history_verified") is True and run.get("oracle_status") == "Valid")
    if config.get("evidence") == "full" and not full:
        reasons.append("full-history oracle failed, was inconclusive, or was not run")
    if config.get("evidence") == "metrics" and (run.get("history_checked") is not False or run.get("correctness_history_verified") is not False or run.get("oracle_status") != "NotCheckedMetricsOnly"):
        reasons.append("metrics-only report misstates history verification")
    try:
        outcomes = collect_outcomes(run)
        if not all(name in outcomes for name in EFFECT_FIELDS + ("missing_family", "allocation_deferred", "ignored_stale")):
            raise ValueError("missing required lifecycle effect counters")
        per_kind_completed = sum(value.get("completed", -expected) for value in run.get("per_kind", {}).values())
        if per_kind_completed != expected:
            raise ValueError("per-kind completion counts differ from corpus")
        expected_kinds = expected_kind_counts(config, expected)
        if (run.get("message_kinds") != expected_kinds
                or {name: value.get("completed") for name, value in run.get("per_kind", {}).items()} != expected_kinds):
            raise ValueError("message kind counts differ from the declared corpus")
    except (ValueError, TypeError) as error:
        reasons.append(str(error))
        outcomes = {}
    latency = run.get("message_latency_p99_us_including_retries")
    throughput = run.get("completed_messages_per_second_including_drain")
    if not finite_number(latency) or latency < 0 or not finite_number(throughput) or throughput <= 0:
        reasons.append("missing or invalid end-to-end latency/drained throughput")
    result.update(outcomes=outcomes, completed_messages=run.get("completed_messages"),
                  p99_ms=latency / 1000 if finite_number(latency) else None,
                  throughput_with_drain=throughput, per_kind=run.get("per_kind", {}),
                  configured_identities=config.get("families"),
                  initial_observed_live_families=run.get("initial_fleet", {}).get("live_families"),
                  final_observed_live_families=run.get("final_fleet", {}).get("live_families"),
                  population_scope="initial/final snapshots; not a runtime minimum")
    result["execution_valid"] = not reasons
    result["history_verified"] = full and not reasons
    result["correctness_companion_verified"] = not reasons and (full or key(config) in companion_keys)
    if reasons:
        return result
    noops = outcomes.get("missing_family", 0) + outcomes.get("allocation_deferred", 0)
    result["no_op_fraction"] = noops / expected
    useful = (result["no_op_fraction"] <= policy["max_noop_fraction"] and outcomes.get("created_views", 0) > 0 and outcomes.get("expired_families", 0) > 0)
    if config.get("workload") == "fleet":
        population = [result["initial_observed_live_families"], result["final_observed_live_families"]]
        populated = all(type(count) is int and config["families"] // 2 <= count <= 2 * config["families"] for count in population)
        full_cycle = expected >= 16 * config["families"]
        kinds = run.get("per_kind", {})
        projection = kinds.get("global_projection", {}).get("outcomes", {}).get("claimed_events", 0) > 0
        rescheduling = kinds.get("global_reschedule", {}).get("outcomes", {}).get("rescheduled_events", 0) > 0
        cancellation = kinds.get("global_cancel", {}).get("outcomes", {}).get("cancelled_events", 0) > 0
        housekeeping = kinds.get("global_housekeeping", {}).get("outcomes", {}).get("expired_records", 0) > 0
        background = projection and rescheduling and cancellation and housekeeping
        useful = useful and populated and full_cycle and background
        result.update(fleet_population_snapshots_passed=populated, fleet_complete_phase_cycle=full_cycle,
                      fleet_global_projection_mutated=projection, fleet_global_rescheduling_mutated=rescheduling,
                      fleet_global_cancellation_mutated=cancellation, fleet_global_housekeeping_mutated=housekeeping)
        if not populated:
            reasons.append("fleet initial/final population snapshot missing or below configured-identity threshold")
        if not full_cycle:
            reasons.append("fleet capacity needs at least sixteen rounds of configured identities")
        if not background:
            reasons.append("fleet projection/rescheduling/cancellation/housekeeping did not all mutate records")
    result["useful_work_passed"] = useful
    if not useful:
        reasons.append("lifecycle lacks creation/expiry turnover or exceeds missing/deferred limit")
    slo = latency <= policy["slo_ms"] * 1000
    rate = throughput >= config["arrival_rate"] * policy["minimum_drain_fraction"]
    if not slo:
        reasons.append("declared end-to-end p99 SLO exceeded")
    if not rate:
        reasons.append("drained completion rate below declared offered-rate fraction")
    result["performance_passed"] = useful and slo and rate
    result["qualified_capacity_trial"] = result["performance_passed"] and result["correctness_companion_verified"]
    result["capacity_failure"] = useful and result["correctness_companion_verified"] and not (slo and rate)
    if not result["correctness_companion_verified"]:
        reasons.append("no exact source/binary/configuration/corpus full-history companion")
    return result


def build_gate(trials: list[dict], policy: dict, engines: list[str], rates: list[int], workers: list[int], seeds: list[int], companion_keys: set[tuple] = frozenset()) -> dict:
    """Require every declared seed; optimize only across declared worker counts."""
    assessed = []
    common_fields = tuple(field for field in MATCH_FIELDS if field not in {"engine", "workers", "arrival_rate", "seed"})
    common = {tuple(trial["config"].get(field) for field in common_fields) for trial in trials}
    corpus_configuration_matches = len(common) == 1
    for trial in trials:
        assessment = assess_trial(trial, policy, companion_keys)
        if not corpus_configuration_matches:
            assessment.update(execution_valid=False, performance_passed=False, qualified_capacity_trial=False, capacity_failure=False)
            assessment["reasons"].append("matrix changes corpus/configuration beyond the declared rate/worker/seed/engine axes")
        assessed.append({"config": trial["config"], "assessment": assessment})
    grid = {}
    for item in assessed:
        cfg = item["config"]
        cell = (cfg["engine"], cfg["arrival_rate"], cfg["workers"], cfg["seed"])
        grid.setdefault(cell, []).append(item["assessment"])
    def all_seeds(engine, rate, worker, predicate):
        return all(len(grid.get((engine, rate, worker, seed), [])) == 1 and grid[(engine, rate, worker, seed)][0].get(predicate) is True for seed in seeds)
    bounds = {}
    for engine in engines:
        passing = [(rate, worker) for rate in rates for worker in workers if len(seeds) >= 3 and all_seeds(engine, rate, worker, "qualified_capacity_trial")]
        exploratory = [(rate, worker) for rate in rates for worker in workers if all_seeds(engine, rate, worker, "performance_passed")]
        best = max(passing, key=lambda pair: (pair[0], -pair[1]), default=None)
        upper = [rate for rate in rates if best and rate > best[0] and all(all_seeds(engine, rate, worker, "capacity_failure") for worker in workers)]
        bounds[engine] = {"best_tested_qualified_rate": best[0] if best else None,
                          "selected_workers": best[1] if best else None,
                          "best_tested_exploratory_rate": max((r for r, _ in exploratory), default=None),
                          "failing_tested_upper_rate": min(upper, default=None),
                          "all_seed_passes_required": True, "three_or_more_seeds": len(seeds) >= 3,
                          "worker_search_exhaustive_only_within_declared_grid": True}
    comparisons = {}
    pg = bounds.get("postgres", {})
    for engine, bound in bounds.items():
        if engine == "postgres":
            continue
        lower, pg_lower, upper = bound["best_tested_qualified_rate"], pg.get("best_tested_qualified_rate"), pg.get("failing_tested_upper_rate")
        exploratory_a = bound["best_tested_exploratory_rate"]
        exploratory_pg = pg.get("best_tested_exploratory_rate")
        comparison = {"ratio_of_tested_passing_rates": exploratory_a / exploratory_pg if exploratory_a and exploratory_pg else None,
                      "ratio_is_capacity_proof": False, "synthetic_capacity_lower_bound": None,
                      "synthetic_10x_bound_demonstrated": False,
                      "conditional_tested_grid_10x_ratio": False,
                      "hardware_resource_equivalence_verified": False,
                      "saturation_monotonicity_verified": False,
                      "useful_work_comparable": False,
                      "reason": "passing rates are lower bounds; need a repeated PostgreSQL saturation bracket and comparable useful work"}
        if lower and pg_lower and upper:
            # Compare useful work on an identical full corpus at the PG upper
            # rate; comparing different message counts at different rates alone
            # would conflate missing/deferred work with architecture capacity.
            candidates = [w for w in workers if all_seeds(engine, upper, w, "qualified_capacity_trial")]
            comparable = bool(candidates)
            for seed in seeds:
                if not comparable:
                    break
                a = grid[(engine, upper, candidates[0], seed)][0]
                for worker in workers:
                    b = grid[("postgres", upper, worker, seed)][0]
                    endpoint = grid[(engine, lower, bound["selected_workers"], seed)][0]
                    for name in EFFECT_FIELDS + ("missing_family", "allocation_deferred", "ignored_stale"):
                        av, bv = a["outcomes"].get(name, 0), b["outcomes"].get(name, 0)
                        if abs(av - bv) > policy["outcome_tolerance"] * max(av, bv, 1):
                            comparable = False
                        # Higher offered rates cover longer sequence prefixes;
                        # require comparable effects per completed input there
                        # as well, not only at the same-rate control point.
                        normalized_a = endpoint["outcomes"].get(name, 0) / endpoint["completed_messages"]
                        normalized_b = bv / b["completed_messages"]
                        if abs(normalized_a - normalized_b) > policy["outcome_tolerance"] * max(normalized_a, normalized_b, 1 / b["completed_messages"]):
                            comparable = False
            comparison["useful_work_comparable"] = comparable
            if comparable:
                comparison.update(synthetic_capacity_lower_bound=lower / upper,
                                  conditional_tested_grid_10x_ratio=lower >= 10 * upper and policy["outcome_tolerance"] == 0,
                                  reason="conditional synthetic ratio over the declared grid, seeds, duration, SLO and resource budget; strict grid flag requires zero outcome tolerance; a demonstrated capacity bound remains false because resource equivalence and saturation monotonicity are unproven")
        comparisons[engine] = comparison
    return {"trial_assessments": assessed, "capacity_bounds": bounds, "comparisons": comparisons,
            "corpus_configuration_matches": corpus_configuration_matches,
            "whole_engine_verified": False, "actual_hyperfeed_replacement_qualified": False,
            "architecture_promotion_eligible": False, "real_world_10x_claim": False,
            "scope": "exploratory synthetic capacity evidence; compatibility, recovery, MMHF, production retention and resource isolation remain unqualified"}


def descendants(parent: int) -> set[int]:
    parents = {}
    for entry in Path("/proc").iterdir():
        if entry.name.isdigit():
            try:
                parents[int(entry.name)] = int((entry / "stat").read_text().rsplit(") ", 1)[1].split()[1])
            except (OSError, ValueError, IndexError):
                pass
    found = {parent}
    while True:
        extended = found | {pid for pid, ppid in parents.items() if ppid in found}
        if extended == found:
            return found - {parent}
        found = extended


def cleanup_private_configs(directory: Path, ownership_token: str) -> list[str]:
    """Remove credential configs only inside a token-marked owned trial tree.

    Directory symlinks are never followed. No other filename is removed, and
    the token guard prevents accidentally passing the whole output/repo root.
    Call only after the owned processes have terminated.
    """
    if not ownership_token or (directory / ".qualification-owned-trial").read_text() != ownership_token:
        raise ValueError("private-config cleanup requires the exact owned trial directory")
    removed = []
    for current, directories, filenames in os.walk(directory, followlinks=False):
        directories[:] = [name for name in directories if not (Path(current) / name).is_symlink()]
        for name in filenames:
            if re.fullmatch(r"(?:private-config|worker-[0-9]+)\.json", name):
                path = Path(current) / name
                path.unlink()
                removed.append(str(path.relative_to(directory)))
    return sorted(removed)


def live_owned_processes(group: int, known: set[int]) -> set[int]:
    live = set()
    for entry in Path("/proc").iterdir():
        if entry.name.isdigit():
            try:
                fields = (entry / "stat").read_text().rsplit(") ", 1)[1].split()
                pid = int(entry.name)
                if fields[0] not in {"Z", "X"} and (pid in known or int(fields[2]) == group):
                    live.add(pid)
            except (OSError, ValueError, IndexError):
                pass
    return live


def run_process(command: list[str], log: Path, timeout: float, secrets: tuple[str, ...] = (),
                owned_directory: Path | None = None, ownership_token: str | None = None) -> dict:
    """Bounded process-tree cleanup; private temporary stdout is scrubbed."""
    started = time.monotonic()
    timed_out = False
    error = None
    code = None
    terminated = False
    removed = []
    with tempfile.TemporaryFile(mode="w+b", dir=log.parent) as raw:
        process = subprocess.Popen(command, cwd=ROOT, stdout=raw, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
        except BaseException:
            error = "interrupted while waiting for benchmark"
            raise
        finally:
            children = set()
            if process.poll() is None:
                children = descendants(process.pid)
                for pid in children:
                    try:
                        os.kill(pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                code = process.wait(timeout=5)
            # The Rust runner owns its nested coordinator groups. For forced
            # termination we captured and killed those descendants above; also
            # ensure no live member remains in the outer group after any exit.
            deadline = time.monotonic() + 5
            while True:
                live = live_owned_processes(process.pid, children)
                if not live:
                    terminated = True
                    break
                for pid in live:
                    try:
                        os.kill(pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                if time.monotonic() >= deadline:
                    error = "owned process termination unconfirmed; private cleanup not attempted"
                    break
                time.sleep(.01)
            if terminated and owned_directory is not None:
                removed = cleanup_private_configs(owned_directory, ownership_token or "")
            raw.seek(0)
            content = raw.read().decode("utf-8", errors="replace")
            for secret in secrets:
                if secret:
                    content = content.replace(secret, "<redacted>")
            log.write_text(content)
    return {"exit_code": code, "timed_out": timed_out, "error": error, "wall_seconds": time.monotonic() - started,
            "owned_processes_terminated": terminated, "private_configs_removed": removed}


def host_info() -> dict:
    def read(path):
        try:
            return Path(path).read_text().strip()
        except OSError:
            return None
    return {"platform": platform.platform(), "machine": platform.machine(), "logical_cpus": os.cpu_count(),
            "cpu_affinity": sorted(os.sched_getaffinity(0)), "load_average": list(os.getloadavg()),
            "meminfo": read("/proc/meminfo"), "cgroup_cpu_max": read("/sys/fs/cgroup/cpu.max"),
            "cgroup_memory_max": read("/sys/fs/cgroup/memory.max"),
            "cpu_models": sorted({line.split(":", 1)[1].strip() for line in (read("/proc/cpuinfo") or "").splitlines() if line.startswith("model name")})}


def comma_ints(value: str) -> list[int]:
    try:
        values = [int(part) for part in value.split(",")]
        if not values or len(values) != len(set(values)) or min(values) < 0:
            raise ValueError()
        return values
    except ValueError as error:
        raise argparse.ArgumentTypeError("expected distinct nonnegative comma-separated integers") from error


def main(argv=None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    # Invalidate even a configuration error; argparse otherwise exits before
    # the normal setup path. Help is informational and leaves prior data alone.
    output_hint = None
    for index, argument in enumerate(arguments):
        if argument == "--output" and index + 1 < len(arguments):
            output_hint = arguments[index + 1]
        elif argument.startswith("--output="):
            output_hint = argument.split("=", 1)[1]
    if output_hint and not any(arg in {"--help", "-h"} for arg in arguments):
        atomic_json(Path(output_hint).resolve() / "campaign.json",
                    {"format": FORMAT, "completed": False, "passed": False, "source_stable": False,
                     "stage": "configuration", "trials": [], "architecture_promotion_eligible": False})
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pg-url-env", default="AEROSTORE_CONTENTION_PG_URL")
    parser.add_argument("--engines", default="aerostore,postgres")
    parser.add_argument("--workload", choices=["lifecycle", "fleet"], default="lifecycle")
    parser.add_argument("--rates", type=comma_ints, default=[32, 64])
    parser.add_argument("--workers", type=comma_ints, default=[1, 2])
    parser.add_argument("--seeds", type=comma_ints, default=[20260924, 20260925, 20260926])
    parser.add_argument("--seconds", type=int, default=5)
    parser.add_argument("--slo-ms", type=float, required=True, help="declared synthetic test budget, not a known HyperFeed SLA")
    parser.add_argument("--families", type=int, default=16)
    parser.add_argument("--hot-percent", type=int, default=80)
    parser.add_argument("--max-backlog", type=int, default=1000)
    parser.add_argument("--max-messages", type=int, default=100000)
    parser.add_argument("--max-worker-budget", type=int, default=32)
    parser.add_argument("--cpu-budget", type=int, default=len(os.sched_getaffinity(0)))
    parser.add_argument("--shm-mib", type=int, default=256)
    parser.add_argument("--pg-write-mode", choices=["buffered", "immediate"], default="buffered")
    parser.add_argument("--rpc-delay-us", type=int, default=0)
    parser.add_argument("--evidence", choices=["full", "metrics"], default="metrics")
    parser.add_argument("--correctness-report", type=Path)
    parser.add_argument("--timeout-seconds", type=float, help="per trial; default seconds + 420")
    parser.add_argument("--max-noop-fraction", type=float, default=0.25)
    parser.add_argument("--minimum-drain-fraction", type=float, default=0.95)
    parser.add_argument("--outcome-tolerance", type=float, default=0.10)
    args = parser.parse_args(arguments)
    engines = args.engines.split(",")
    if (not engines or len(set(engines)) != len(engines) or any(e not in ENGINES for e in engines)
            or not 1 <= min(args.rates) <= max(args.rates) <= 1000000
            or not 1 <= min(args.workers) <= max(args.workers) <= args.max_worker_budget <= 32
            or not 1 <= args.seconds <= 3600 or not 1 <= args.families <= 1024
            or (args.workload == "fleet" and (args.families < 16 or args.hot_percent != 0))
            or not 0 <= args.hot_percent <= 100 or args.cpu_budget < 1
            or not 1 <= args.max_backlog <= 100000 or not 1 <= args.max_messages <= 100000
            or not 32 <= args.shm_mib <= 3584 or not 0 <= args.rpc_delay_us <= 1000000
            or (args.rpc_delay_us and any(not engine.startswith("service-") for engine in engines))
            or not finite_number(args.slo_ms) or args.slo_ms <= 0
            or not 0 <= args.max_noop_fraction <= 1 or not 0 < args.minimum_drain_fraction <= 1
            or not 0 <= args.outcome_tolerance <= 1
            or (args.timeout_seconds is not None and (not finite_number(args.timeout_seconds) or args.timeout_seconds <= 0))
            or max(args.seeds) >= 2**64
            or min(args.rates) * args.seconds < max(args.workers)
            or math.ceil(max(args.rates) * args.seconds / min(args.workers)) > args.max_messages):
        parser.error("invalid bounded matrix, resource budget, latency policy, or per-worker corpus size")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    report_path = output / "campaign.json"
    # Immediately invalidate an old success, including before binary/PG setup.
    campaign = {"format": FORMAT, "completed": False, "passed": False, "source_stable": False,
                "started_at": datetime.now(timezone.utc).isoformat(), "trials": [],
                "whole_engine_verified": False, "actual_hyperfeed_replacement_qualified": False,
                "architecture_promotion_eligible": False, "exploratory": True}
    atomic_json(report_path, campaign)
    try:
        binary = args.binary.resolve(strict=True)
        secret = os.environ.get(args.pg_url_env, "")
        if "postgres" in engines and not secret:
            raise ValueError(f"PostgreSQL requires the named environment variable {args.pg_url_env}")
        password = unquote(urlsplit(secret).password or "") if "://" in secret else next((token.split("=", 1)[1] for token in shlex.split(secret) if token.startswith("password=")), "")
        secrets = tuple(value for value in (secret, password) if value)
        source = snapshot_sources()
        binary_sha = sha256(binary)
        policy = {name: getattr(args, name) for name in ("slo_ms", "max_noop_fraction", "minimum_drain_fraction", "outcome_tolerance")}
        campaign.update(source_before=source, binary_before_sha256=binary_sha, binary_path=str(binary),
                        compiler=subprocess.check_output(["rustc", "-Vv"], cwd=ROOT, text=True, timeout=10).strip(),
                        compiler_metadata_scope="current rustc -Vv; driver does not attest the compiler or sources used to build a caller-supplied binary",
                        binary_build_provenance="caller supplies built binary; hashes identify measured bytes but do not reconstruct its build",
                        git_revision=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=10).strip(),
                        host_before=host_info(), policy=policy,
                        matrix={"engines": engines, "rates": args.rates, "workers": args.workers, "seeds": args.seeds, "seconds": args.seconds},
                        resource_budget={"maximum_workers": args.max_worker_budget, "declared_cpus": args.cpu_budget,
                                         "native_shm_mib": args.shm_mib, "affinity_enforced": False,
                                         "note": "declared budget only; shared-host interference and PostgreSQL resource equivalence are not controlled"})
        companion = None
        if args.correctness_report:
            companion = json.loads(args.correctness_report.read_text())
            campaign["correctness_report"] = {"path": str(args.correctness_report.resolve()), "sha256": sha256(args.correctness_report)}
        companion_ok = compatible_companion(companion, source, binary_sha)
        campaign["correctness_companion_provenance_compatible"] = companion_ok
        companion_keys = set()
        if companion_ok:
            for trial in companion.get("trials", []):
                if (trial.get("source_before_sha256") == source["sha256"] == trial.get("source_after_sha256")
                        and trial.get("binary_before_sha256") == binary_sha == trial.get("binary_after_sha256")
                        and assess_trial(trial, policy)["history_verified"]):
                    companion_keys.add(key(trial["config"]))
        atomic_json(report_path, campaign)
        for index, (seed, rate, workers) in enumerate(itertools.product(args.seeds, args.rates, args.workers)):
            for engine in engines if index % 2 == 0 else reversed(engines):
                directory = Path(tempfile.mkdtemp(prefix=f"{engine}-r{rate}-w{workers}-s{seed}-", dir=output))
                ownership_token = uuid.uuid4().hex
                (directory / ".qualification-owned-trial").write_text(ownership_token)
                config = {"engine": engine, "workload": args.workload, "evidence": args.evidence,
                          "families": args.families, "hot_percent": args.hot_percent, "seed": seed,
                          "arrival_rate": rate, "seconds": args.seconds, "workers": workers,
                          "pg_write_mode": args.pg_write_mode, "rpc_delay_us": args.rpc_delay_us,
                          "global_time_predicates": False, "shm_mib": args.shm_mib,
                          "max_backlog": args.max_backlog, "max_messages": args.max_messages,
                          "message_interval_us": 0}
                command = [str(binary), "--mode", "sustained", "--output", str(directory / "report.json")]
                for field in ("engine", "workload", "evidence", "families", "hot_percent", "seed", "arrival_rate", "seconds", "workers", "pg_write_mode", "rpc_delay_us"):
                    command += ["--" + field.replace("_", "-"), str(config[field])]
                command += ["--max-backlog", str(args.max_backlog), "--max-messages", str(args.max_messages), "--shm-mib", str(args.shm_mib)]
                public_command = command.copy()
                if engine == "postgres":
                    command += ["--pg-url", secret]
                    public_command += ["--pg-url", "<environment:" + args.pg_url_env + ">"]
                before = snapshot_sources()
                before_binary = sha256(binary)
                trial = {"config": config, "directory": str(directory), "command": public_command,
                         "source_before_sha256": before["sha256"], "binary_before_sha256": before_binary}
                campaign["trials"].append(trial)
                atomic_json(report_path, campaign)
                print(f"START {engine} rate={rate} workers={workers} seed={seed}", flush=True)
                try:
                    trial.update(run_process(command, directory / "run.log", args.timeout_seconds or args.seconds + 420, secrets,
                                             directory, ownership_token))
                    raw = (directory / "report.json").read_text()
                    for value in secrets:
                        raw = raw.replace(value, "<redacted>")
                    (directory / "report.json").write_text(raw)
                    trial["report"] = json.loads(raw)
                except Exception as error:
                    trial["error"] = type(error).__name__ + ": " + str(error)
                    for value in secrets:
                        trial["error"] = trial["error"].replace(value, "<redacted>")
                after = snapshot_sources()
                after_binary = sha256(binary)
                trial.update(source_after_sha256=after["sha256"], binary_after_sha256=after_binary,
                             source_stable=source == before == after and binary_sha == before_binary == after_binary)
                trial["assessment"] = assess_trial(trial, policy, companion_keys)
                atomic_json(directory / "trial.json", trial)
                atomic_json(report_path, campaign)
                print(f"DONE {engine} valid={trial['assessment']['execution_valid']} capacity_pass={trial['assessment']['qualified_capacity_trial']}", flush=True)
        campaign.update(source_after=snapshot_sources(), binary_after_sha256=sha256(binary), host_after=host_info(), completed=True)
        campaign["source_stable"] = campaign["source_before"] == campaign["source_after"] and binary_sha == campaign["binary_after_sha256"] and all(t["source_stable"] for t in campaign["trials"])
        if not campaign["source_stable"]:
            for trial in campaign["trials"]:
                trial["source_stable"] = False
        campaign["gate"] = build_gate(campaign["trials"], policy, engines, args.rates, args.workers, args.seeds, companion_keys)
        campaign["passed"] = campaign["source_stable"] and all(t["assessment"]["execution_valid"] for t in campaign["gate"]["trial_assessments"])
    except Exception as error:
        campaign["operational_error"] = type(error).__name__ + ": " + str(error)
    finally:
        atomic_json(report_path, campaign)
    return 0 if campaign["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
