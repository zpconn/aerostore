#!/usr/bin/env python3
"""Adversarial gate tests; no database or benchmark is started."""
import copy
import contextlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest

import qualify_hyperfeed as gate


POLICY = {"slo_ms": 100, "max_noop_fraction": .25,
          "minimum_drain_fraction": .95, "outcome_tolerance": 0}
SEEDS = [11, 22, 33]


def trial(engine="aerostore", rate=32, workers=1, seed=11, evidence="full", p99_ms=1):
    config = {"engine": engine, "workload": "lifecycle", "evidence": evidence,
              "families": 4, "hot_percent": 80, "seed": seed, "arrival_rate": rate,
              "seconds": 5, "workers": workers, "pg_write_mode": "buffered", "rpc_delay_us": 0,
              "global_time_predicates": False, "shm_mib": 256, "max_backlog": 1000,
              "max_messages": 100000, "message_interval_us": 0}
    offered = rate * 5
    counts = gate.lifecycle_kind_counts(offered)
    outcomes = {name: 0 for name in gate.EFFECT_FIELDS + ("missing_family", "allocation_deferred", "ignored_stale")}
    outcomes.update(created_views=offered, updated_views=offered, outputs=offered,
                    expired_records=offered, expired_families=offered // 16)
    per_kind = {name: {"completed": count, "outcomes": {key: 0 for key in outcomes}} for name, count in counts.items()}
    per_kind["plan"]["outcomes"] = outcomes
    run = {"engine": engine, "scenario": "sustained-mixed", "passed": True, "execution_completed": True,
           "arrival_mode": "independent_fixed_corpus", "offered_messages": offered, "completed_messages": offered,
           "completed_by_worker": [(offered - 1 - worker) // workers + 1 for worker in range(workers)],
           "admission_seconds": 5, "offered_rate_per_second": rate, "requested_duration_reached": True,
           "worker_message_cap_reached": False, "elapsed_seconds": 5.001,
           "worker_stops": [{"stop_reason": "arrival_corpus_drained"} for _ in range(workers)],
           "invariants": {"passed": True}, "store_metrics": {"commits": offered},
           "history_checked": evidence == "full", "correctness_history_verified": evidence == "full",
           "oracle_status": "Valid" if evidence == "full" else "NotCheckedMetricsOnly",
           "message_latency_p99_us_including_retries": p99_ms * 1000,
           "completed_messages_per_second_including_drain": rate * .99,
           "message_kinds": counts, "per_kind": per_kind}
    return {"config": config, "exit_code": 0, "timed_out": False, "source_stable": True,
            "report": {"completed": True, "passed": True, "config": {**config, "mode": "sustained"}, "runs": [run]}}


class QualificationTests(unittest.TestCase):
    def test_full_history_has_qualified_test_capacity_without_engine_promotion(self):
        verdict = gate.assess_trial(trial(), POLICY)
        self.assertTrue(verdict["history_verified"])
        self.assertTrue(verdict["qualified_capacity_trial"])
        result = gate.build_gate([trial(seed=seed) for seed in SEEDS], POLICY, ["aerostore"], [32], [1], SEEDS)
        self.assertEqual(result["capacity_bounds"]["aerostore"]["best_tested_qualified_rate"], 32)
        self.assertFalse(result["whole_engine_verified"])
        self.assertFalse(result["actual_hyperfeed_replacement_qualified"])
        self.assertFalse(result["architecture_promotion_eligible"])

    def test_metrics_alone_cannot_claim_history_or_qualified_capacity(self):
        evidence = trial(evidence="metrics")
        verdict = gate.assess_trial(evidence, POLICY)
        self.assertTrue(verdict["execution_valid"])
        self.assertTrue(verdict["performance_passed"])
        self.assertFalse(verdict["history_verified"])
        self.assertFalse(verdict["qualified_capacity_trial"])
        verdict = gate.assess_trial(evidence, POLICY, {gate.key(evidence["config"])})
        self.assertTrue(verdict["qualified_capacity_trial"])
        self.assertFalse(verdict["history_verified"], "a companion never verifies an unrecorded run")

    def test_companion_requires_exact_source_binary_and_complete_capture(self):
        source = {"sha256": "source", "files": {"dirty.rs": "hash"}}
        companion = {"format": gate.FORMAT, "completed": True, "source_stable": True,
                     "source_before": source, "source_after": copy.deepcopy(source),
                     "binary_before_sha256": "binary", "binary_after_sha256": "binary"}
        self.assertTrue(gate.compatible_companion(companion, source, "binary"))
        for field, value in (("completed", False), ("source_stable", False),
                             ("source_after", {}), ("binary_after_sha256", "other")):
            bad = {**companion, field: value}
            self.assertFalse(gate.compatible_companion(bad, source, "binary"))
        self.assertFalse(gate.compatible_companion({"passed": True, "git_revision": "same"}, source, "binary"))

    def test_companion_corpus_and_worker_configuration_cannot_be_substituted(self):
        evidence = trial(evidence="metrics")
        for field in gate.MATCH_FIELDS:
            wrong = copy.deepcopy(evidence["config"])
            wrong[field] = str(wrong[field]) + "different"
            with self.subTest(field=field):
                self.assertFalse(gate.assess_trial(evidence, POLICY, {gate.key(wrong)})["qualified_capacity_trial"])

    def test_errors_timeouts_source_drift_and_progress_failures_are_not_saturation(self):
        for change in ({"exit_code": 1}, {"timed_out": True}, {"source_stable": False}, {"error": "128 retries"}):
            evidence = trial(p99_ms=999)
            evidence.update(change)
            verdict = gate.assess_trial(evidence, POLICY)
            self.assertFalse(verdict["execution_valid"])
            self.assertFalse(verdict["capacity_failure"])
        evidence = trial(p99_ms=999)
        evidence["report"]["runs"][0].update(passed=False, error="no worker progress")
        self.assertFalse(gate.assess_trial(evidence, POLICY)["capacity_failure"])

    def test_wrong_or_incomplete_corpus_is_rejected(self):
        changes = [{"completed_messages": 159}, {"offered_messages": 159},
                   {"completed_by_worker": [159]}, {"arrival_mode": "closed_loop"},
                   {"requested_duration_reached": False}, {"elapsed_seconds": .1},
                   {"worker_message_cap_reached": True}, {"admission_seconds": 4},
                   {"worker_stops": [{"stop_reason": "message_cap"}]},
                   {"message_kinds": {"plan": 160}}, {"store_metrics": {"commits": 159}}]
        for change in changes:
            evidence = trial()
            evidence["report"]["runs"][0].update(change)
            with self.subTest(change=change):
                self.assertFalse(gate.assess_trial(evidence, POLICY)["execution_valid"])
        evidence = trial()
        evidence["report"]["config"]["seed"] += 1
        self.assertFalse(gate.assess_trial(evidence, POLICY)["execution_valid"])

    def test_invalid_or_inconclusive_history_never_qualifies(self):
        for status in ("Invalid", "Inconclusive", "NotCheckedMetricsOnly"):
            evidence = trial()
            evidence["report"]["runs"][0]["oracle_status"] = status
            self.assertFalse(gate.assess_trial(evidence, POLICY)["qualified_capacity_trial"])
        evidence = trial(evidence="metrics")
        evidence["report"]["runs"][0]["history_checked"] = True
        self.assertFalse(gate.assess_trial(evidence, POLICY)["execution_valid"])

    def test_useful_work_collapse_cannot_qualify_capacity(self):
        for field, value in (("missing_family", 100), ("allocation_deferred", 100), ("created_views", 0), ("expired_families", 0)):
            evidence = trial()
            evidence["report"]["runs"][0]["per_kind"]["plan"]["outcomes"][field] = value
            with self.subTest(field=field):
                verdict = gate.assess_trial(evidence, POLICY)
                self.assertTrue(verdict["execution_valid"])
                self.assertFalse(verdict["performance_passed"])
                self.assertFalse(verdict["capacity_failure"])

    def test_every_seed_must_pass_and_one_seed_cannot_establish_repeated_capacity(self):
        trials = [trial(seed=seed) for seed in SEEDS]
        trials[-1]["report"]["runs"][0]["message_latency_p99_us_including_retries"] = 999000
        result = gate.build_gate(trials, POLICY, ["aerostore"], [32], [1], SEEDS)
        self.assertIsNone(result["capacity_bounds"]["aerostore"]["best_tested_qualified_rate"])
        result = gate.build_gate([trial()], POLICY, ["aerostore"], [32], [1], [11])
        self.assertIsNone(result["capacity_bounds"]["aerostore"]["best_tested_qualified_rate"])

    def test_two_passing_lower_bounds_do_not_prove_tenfold_capacity(self):
        trials = [trial(engine=engine, rate=rate, seed=seed) for engine, rate in (("aerostore", 320), ("postgres", 32)) for seed in SEEDS]
        result = gate.build_gate(trials, POLICY, ["aerostore", "postgres"], [32, 320], [1], SEEDS)
        comparison = result["comparisons"]["aerostore"]
        self.assertEqual(comparison["ratio_of_tested_passing_rates"], 10)
        self.assertIsNone(comparison["synthetic_capacity_lower_bound"])
        self.assertFalse(comparison["synthetic_10x_bound_demonstrated"])

    def saturation_trials(self):
        return [trial(engine=engine, rate=rate, workers=workers, seed=seed,
                      p99_ms=999 if engine == "postgres" and rate >= 64 else 1)
                for engine in ("aerostore", "postgres") for rate in (32, 64, 640)
                for workers in (1, 2) for seed in SEEDS]

    def test_saturation_requires_all_worker_choices_and_seed_failures(self):
        trials = self.saturation_trials()
        result = gate.build_gate(trials, POLICY, ["aerostore", "postgres"], [32, 64, 640], [1, 2], SEEDS)
        self.assertEqual(result["capacity_bounds"]["postgres"]["failing_tested_upper_rate"], 64)
        self.assertEqual(result["capacity_bounds"]["aerostore"]["selected_workers"], 1)
        self.assertEqual(result["comparisons"]["aerostore"]["synthetic_capacity_lower_bound"], 10)
        self.assertTrue(result["comparisons"]["aerostore"]["conditional_tested_grid_10x_ratio"])
        self.assertFalse(result["comparisons"]["aerostore"]["synthetic_10x_bound_demonstrated"])
        self.assertFalse(result["comparisons"]["aerostore"]["hardware_resource_equivalence_verified"])
        self.assertFalse(result["real_world_10x_claim"])
        for item in trials:
            if item["config"]["engine"] == "postgres" and item["config"]["workers"] == 2 and item["config"]["arrival_rate"] >= 64:
                item["exit_code"] = 1
        result = gate.build_gate(trials, POLICY, ["aerostore", "postgres"], [32, 64, 640], [1, 2], SEEDS)
        self.assertIsNone(result["capacity_bounds"]["postgres"]["failing_tested_upper_rate"])
        self.assertFalse(result["comparisons"]["aerostore"]["synthetic_10x_bound_demonstrated"])

    def test_saturation_cannot_hide_mismatched_useful_work_at_high_rate(self):
        trials = self.saturation_trials()
        for item in trials:
            if item["config"]["engine"] == "aerostore" and item["config"]["arrival_rate"] == 640:
                item["report"]["runs"][0]["per_kind"]["plan"]["outcomes"]["updated_views"] //= 2
        result = gate.build_gate(trials, POLICY, ["aerostore", "postgres"], [32, 64, 640], [1, 2], SEEDS)
        self.assertFalse(result["comparisons"]["aerostore"]["useful_work_comparable"])
        self.assertIsNone(result["comparisons"]["aerostore"]["synthetic_capacity_lower_bound"])

    def test_different_engine_corpora_cannot_be_compared_as_one_matrix(self):
        trials = self.saturation_trials()
        for item in trials:
            if item["config"]["engine"] == "aerostore":
                item["config"]["families"] = 1
                item["report"]["config"]["families"] = 1
        result = gate.build_gate(trials, POLICY, ["aerostore", "postgres"], [32, 64, 640], [1, 2], SEEDS)
        self.assertFalse(result["corpus_configuration_matches"])
        self.assertIsNone(result["capacity_bounds"]["aerostore"]["best_tested_qualified_rate"])
        self.assertIsNone(result["comparisons"]["aerostore"]["synthetic_capacity_lower_bound"])

    def test_missing_and_duplicate_matrix_trials_cannot_establish_capacity(self):
        for trials in ([trial(seed=11), trial(seed=22)], [trial(seed=seed) for seed in SEEDS] + [trial()]):
            result = gate.build_gate(trials, POLICY, ["aerostore"], [32], [1], SEEDS)
            self.assertIsNone(result["capacity_bounds"]["aerostore"]["best_tested_qualified_rate"])

    def test_working_source_fingerprint_detects_dirty_and_new_proof_inputs(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "aerostore_core/src").mkdir(parents=True)
            source = root / "aerostore_core/src/lib.rs"
            source.write_text("before")
            before = gate.snapshot_sources(root)
            source.write_text("after")
            self.assertNotEqual(before, gate.snapshot_sources(root))
            source.write_text("before")
            self.assertEqual(before, gate.snapshot_sources(root))
            (root / "verification").mkdir()
            (root / "verification/new.lean").write_text("theorem")
            self.assertNotEqual(before, gate.snapshot_sources(root))

    def test_timeout_kills_descendant_and_redacts_logs(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            pid_file = root / "child.pid"
            code = "import os,subprocess,time,pathlib; p=subprocess.Popen(['sleep','30'], start_new_session=True); pathlib.Path(%r).write_text(str(p.pid)); print('SECRET_URL',flush=True); time.sleep(30)" % str(pid_file)
            outcome = gate.run_process([sys.executable, "-c", code], root / "run.log", .2, ("SECRET_URL",))
            self.assertTrue(outcome["timed_out"])
            self.assertLess(outcome["wall_seconds"], 5)
            self.assertNotIn("SECRET_URL", (root / "run.log").read_text())
            pid = int(pid_file.read_text())
            for _ in range(100):
                path = Path(f"/proc/{pid}/stat")
                if not path.exists() or path.read_text().rsplit(") ", 1)[1].startswith("Z"):
                    break
                time.sleep(.01)
            else:
                self.fail("descendant survived timeout cleanup")

    def test_timeout_removes_only_exact_private_configs_inside_owned_trial(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            owned = root / "trial"
            owned.mkdir()
            (owned / ".qualification-owned-trial").write_text("token")
            external = root / "external"
            external.mkdir()
            (external / "private-config.json").write_text("outside-owned-tree")
            (owned / "external-link").symlink_to(external, target_is_directory=True)
            child_code = ("import pathlib,time; p=pathlib.Path(%r); (p/'case').mkdir(); "
                          "(p/'case/private-config.json').write_text('CREDENTIAL'); "
                          "(p/'case/worker-0.json').write_text('CREDENTIAL'); "
                          "(p/'case/worker-not-number.json').write_text('retain'); "
                          "(p/'case/history.jsonl').write_text('retain'); time.sleep(30)") % str(owned)
            outcome = gate.run_process([sys.executable, "-c", child_code], owned / "run.log", .2,
                                       ("CREDENTIAL",), owned, "token")
            self.assertTrue(outcome["timed_out"])
            self.assertTrue(outcome["owned_processes_terminated"])
            self.assertEqual(outcome["private_configs_removed"], ["case/private-config.json", "case/worker-0.json"])
            self.assertFalse((owned / "case/private-config.json").exists())
            self.assertFalse((owned / "case/worker-0.json").exists())
            self.assertEqual((external / "private-config.json").read_text(), "outside-owned-tree")
            self.assertTrue((owned / "case/worker-not-number.json").exists())
            self.assertTrue((owned / "case/history.jsonl").exists())
            with self.assertRaises((ValueError, FileNotFoundError)):
                gate.cleanup_private_configs(root, "token")

    def test_missing_binary_invalidates_stale_success_without_running_trials(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "campaign.json").write_text(json.dumps({"passed": True}))
            code = gate.main(["--binary", str(root / "missing"), "--output", str(root), "--engines", "aerostore", "--slo-ms", "100"])
            self.assertEqual(code, 1)
            report = json.loads((root / "campaign.json").read_text())
            self.assertFalse(report["passed"])
            self.assertFalse(report["completed"])
            self.assertEqual(report["trials"], [])

    def test_invalid_arguments_also_invalidate_stale_success(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "campaign.json").write_text(json.dumps({"passed": True}))
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                gate.main(["--binary", str(root / "missing"), "--output=" + str(root),
                           "--workers", "0", "--slo-ms", "100"])
            report = json.loads((root / "campaign.json").read_text())
            self.assertFalse(report["passed"])
            self.assertFalse(report["completed"])
            self.assertEqual(report["stage"], "configuration")


if __name__ == "__main__":
    unittest.main()
