#!/usr/bin/env python3
"""Real-binary regressions for arrival timing and fail-closed evidence modes.

Run after rebuilding the bench:
  AEROSTORE_CONTENTION_BINARY=/absolute/path/to/hyperfeed_contention_crucible \
    python3 -m unittest discover -s scripts -p test_contention_integration.py -v

No PostgreSQL server is required. Outputs are retained under target/ by default;
set AEROSTORE_CONTENTION_INTEGRATION_OUTPUT to select their parent directory.
Without an explicitly selected binary these integration tests are skipped.
"""
import json
import os
from pathlib import Path
import tempfile
import unittest

import qualify_hyperfeed as gate


@unittest.skipUnless(os.environ.get("AEROSTORE_CONTENTION_BINARY"), "set AEROSTORE_CONTENTION_BINARY to run real-binary regressions")
class ContentionIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.binary = Path(os.environ["AEROSTORE_CONTENTION_BINARY"]).resolve(strict=True)
        output = Path(os.environ.get("AEROSTORE_CONTENTION_INTEGRATION_OUTPUT", gate.ROOT / "target/contention-integration"))
        output.mkdir(parents=True, exist_ok=True)
        cls.output = Path(tempfile.mkdtemp(prefix="regression-", dir=output))

    def run_case(self, name, *options):
        directory = self.output / name
        directory.mkdir()
        report = directory / "report.json"
        command = [str(self.binary), "--engine", "aerostore", "--mode", "sustained",
                   "--workload", "lifecycle", "--evidence", "metrics", "--workers", "1",
                   "--families", "2", "--hot-percent", "80", "--seed", "20260924",
                   "--seconds", "1", "--arrival-rate", "1", "--max-messages", "1000",
                   "--shm-mib", "128", "--output", str(report), *options]
        receipt = gate.run_process(command, directory / "run.log", 45)
        self.assertFalse(receipt["timed_out"], f"timeout; retained log: {directory / 'run.log'}")
        self.assertTrue(report.exists(), f"missing failure/success report: {directory}")
        return receipt, json.loads(report.read_text())

    def successful(self, name, *options):
        receipt, report = self.run_case(name, *options)
        self.assertEqual(receipt["exit_code"], 0, report)
        self.assertIs(report["passed"], True)
        self.assertIs(report["completed"], True)
        self.assertEqual(len(report["runs"]), 1)
        return report["runs"][0]

    def test_one_arrival_waits_for_full_admission_interval_and_metrics_omit_history(self):
        run = self.successful("one-arrival")
        self.assertEqual(run["offered_messages"], 1)
        self.assertEqual(run["completed_messages"], 1)
        self.assertEqual(run["completed_by_worker"], [1])
        self.assertGreaterEqual(run["elapsed_seconds"], 1.0)
        self.assertTrue(run["requested_duration_reached"])
        self.assertFalse(run["worker_message_cap_reached"])
        self.assertFalse(run["history_checked"])
        self.assertFalse(run["correctness_history_verified"])
        self.assertEqual(run["oracle_status"], "NotCheckedMetricsOnly")
        history = Path(run["evidence_directory"]) / "history.jsonl"
        observations = [json.loads(line) for line in history.read_text().splitlines()]
        self.assertEqual(len(observations), 1)
        observation = observations[0]
        self.assertEqual(observation["receipt"]["body"]["operations"], [])
        self.assertLessEqual(observation["scheduled_ns"], observation["message_started_ns"])
        self.assertEqual(observation["end_to_end_latency_ns"], observation["received_ns"] - observation["scheduled_ns"])
        self.assertEqual(observation["service_latency_ns"], observation["receipt"]["finished"] - observation["message_started_ns"])
        self.assertGreaterEqual(run["worker_stops"][0]["finished_ns"], observation["scheduled_ns"] + 1_000_000_000)

    def test_full_and_metrics_process_the_same_fixed_single_worker_corpus(self):
        full = self.successful("full-corpus", "--arrival-rate", "32", "--evidence", "full")
        metrics = self.successful("metrics-corpus", "--arrival-rate", "32")
        self.assertTrue(full["history_checked"])
        self.assertTrue(full["correctness_history_verified"])
        self.assertEqual(full["oracle_status"], "Valid")
        self.assertFalse(metrics["correctness_history_verified"])
        for run in (full, metrics):
            self.assertEqual(run["completed_messages"], 32)
            self.assertEqual(run["store_metrics"]["commits"], 32)
            self.assertEqual(run["message_kinds"], gate.lifecycle_kind_counts(32))
            self.assertGreaterEqual(run["elapsed_seconds"], 1.0)
        def observations(run):
            history = Path(run["evidence_directory"]) / "history.jsonl"
            return [json.loads(line)["receipt"] for line in history.read_text().splitlines()]
        full_receipts, metrics_receipts = observations(full), observations(metrics)
        self.assertEqual([r["message"] for r in full_receipts], [r["message"] for r in metrics_receipts])
        self.assertEqual([r["body"]["outcome"] for r in full_receipts], [r["body"]["outcome"] for r in metrics_receipts])
        self.assertTrue(all(r["body"]["operations"] for r in full_receipts))
        self.assertTrue(all(not r["body"]["operations"] for r in metrics_receipts))
        self.assertEqual(json.loads((Path(full["evidence_directory"]) / "final.json").read_text()),
                         json.loads((Path(metrics["evidence_directory"]) / "final.json").read_text()))

    def test_message_cap_cannot_silently_truncate_offered_corpus(self):
        receipt, report = self.run_case("truncated", "--arrival-rate", "32", "--max-messages", "1")
        self.assertNotEqual(receipt["exit_code"], 0)
        self.assertFalse(report["passed"])
        self.assertEqual(len(report["runs"]), 1)
        self.assertFalse(report["runs"][0]["execution_completed"])
        self.assertIn("offered corpus", report["runs"][0]["error"])

    def test_interactive_delay_exposes_backlog_instead_of_throttling_arrivals(self):
        receipt, report = self.run_case("backlog", "--engine", "service-unix", "--arrival-rate", "100",
                                        "--max-backlog", "1", "--rpc-delay-us", "10000")
        self.assertNotEqual(receipt["exit_code"], 0)
        self.assertFalse(report["passed"])
        self.assertEqual(len(report["runs"]), 1)
        self.assertFalse(report["runs"][0]["execution_completed"])
        self.assertIn("backlog", report["runs"][0]["error"])
        self.assertIn("arrivals were not throttled", report["runs"][0]["error"])


if __name__ == "__main__":
    unittest.main()
