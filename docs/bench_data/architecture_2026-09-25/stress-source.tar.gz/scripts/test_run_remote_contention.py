"""Handshake and shell-boundary regressions for the remote benchmark helper."""
import shlex
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import Mock
import run_remote_contention as runner


class RemoteHandshakeTests(unittest.TestCase):
    def test_configuration_placeholder_and_malformed_json_values_are_not_ready(self):
        placeholder = {"schema": 1, "passed": False, "completed": False, "stage": "configuration"}
        for frame in [None, [], True, placeholder, {"version": 1, "run_id": "old"}]:
            self.assertIsNone(runner.ready_setup(frame))
        ready = {"version": 1, "run_id": "new", "initial_rows": [], "endpoint": {"Tcp": "127.0.0.1:9000"}}
        frames = iter([placeholder, ready])
        result = runner.wait_until(lambda: runner.ready_setup(next(frames)), time.monotonic()+2)
        self.assertIs(result, ready)

    def test_stale_completion_marker_never_stops_a_different_server_run(self):
        for frame in [{"run_id": "old", "completed": True}, {"run_id": "new", "completed": 1},
                      {"run_id": "new", "completed": False}, [], None]:
            with self.assertRaisesRegex(RuntimeError, "not for this run"):
                runner.validate_marker(frame, "new")
        runner.validate_marker({"run_id": "new", "completed": True}, "new")

    def test_stale_or_malformed_final_state_is_rejected_before_copy(self):
        for frame in [{"version": 1, "run_id": "old", "passed": True},
                      {"version": 2, "run_id": "new", "passed": True},
                      {"version": 1, "run_id": "new", "passed": "true"}, [], None]:
            with self.assertRaisesRegex(RuntimeError, "missing, malformed or stale"):
                runner.validate_final(frame, "new")
        failure = {"version": 1, "run_id": "new", "passed": False, "error": "audit failed"}
        self.assertIs(runner.validate_final(failure, "new"), failure)

    def test_server_exit_is_not_hidden_while_waiting_for_a_ready_frame(self):
        process = Mock(returncode=2)
        process.poll.return_value = 2
        with self.assertRaisesRegex(RuntimeError, "server exited 2"):
            runner.wait_until(lambda: None, time.monotonic()+60, [("server", process)])
        process.poll.assert_called_once()

    def test_remote_shell_arguments_are_quoted_as_arguments(self):
        arguments = ["exec", "/tmp/a binary;touch UNAUTHORIZED", "--output", "/tmp/$(id)/file 'name'"]
        command = runner.ssh_command("fixture-host", arguments)
        self.assertEqual(shlex.split(command[-1]), arguments)
        self.assertIn("BatchMode=yes", command)
        self.assertEqual(command[-2], "fixture-host")

    def test_independent_supervisor_kills_and_reaps_orphaned_owner_descendant(self):
        with tempfile.TemporaryDirectory() as directory:
            report = Path(directory) / "supervisor.json"
            pidfile = Path(directory) / "child.pid"
            owner = """import os,signal,sys,time
child=os.fork()
if child==0:
    signal.signal(signal.SIGTERM,signal.SIG_IGN)
    while True: time.sleep(10)
with open(sys.argv[1],'w') as stream: stream.write(str(child))
os._exit(0)
"""
            result = subprocess.run([sys.executable, "-c", runner.REMOTE_SUPERVISOR,
                                     "2", str(report), sys.executable, "-c", owner, str(pidfile)],
                                    capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)
            evidence = json.loads(report.read_text())
            self.assertEqual(evidence["reason"], "owner_exited")
            self.assertTrue(evidence["owned_group_kill_sent"])
            self.assertEqual(evidence["adopted_descendants_reaped"], 1)
            with self.assertRaises(ProcessLookupError):
                os.kill(int(pidfile.read_text()), 0)

    def test_independent_supervisor_enforces_owner_deadline(self):
        with tempfile.TemporaryDirectory() as directory:
            report = Path(directory) / "supervisor.json"
            result = subprocess.run([sys.executable, "-c", runner.REMOTE_SUPERVISOR,
                                     "0.1", str(report), sys.executable, "-c", "import time;time.sleep(60)"],
                                    capture_output=True, timeout=5)
            self.assertNotEqual(result.returncode, 0)
            evidence = json.loads(report.read_text())
            self.assertEqual(evidence["reason"], "supervisor_deadline")
            self.assertTrue(evidence["owned_group_kill_sent"])
            with self.assertRaises(ProcessLookupError):
                os.kill(evidence["owner_pid"], 0)


if __name__ == "__main__":
    unittest.main()
