//! Arrival schedules are independent of completions. No generator thread or
//! unbounded queue is needed: the offered corpus is a deterministic timeline.
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ArrivalPlan {
    pub start_ns: u64,
    pub duration_ns: u64,
    pub rate_per_second: u64,
    pub workers: usize,
}

impl ArrivalPlan {
    pub fn offered(&self) -> u64 {
        ((self.duration_ns as u128 * self.rate_per_second as u128).div_ceil(1_000_000_000)) as u64
    }

    pub fn scheduled_ns(&self, sequence: u64) -> Option<u64> {
        if self.rate_per_second == 0 || sequence >= self.offered() {
            return None;
        }
        let offset = sequence as u128 * 1_000_000_000 / self.rate_per_second as u128;
        self.start_ns.checked_add(u64::try_from(offset).ok()?)
    }

    pub fn worker_offered(&self, worker: usize) -> u64 {
        if worker >= self.workers || self.offered() <= worker as u64 {
            return 0;
        }
        (self.offered() - 1 - worker as u64) / self.workers as u64 + 1
    }

    /// Includes the next message waiting to run. Arrivals at the exact end of
    /// the admission interval are excluded; all admitted messages must drain.
    pub fn backlog(&self, worker: usize, completed: u64, now_ns: u64) -> u64 {
        if now_ns < self.start_ns || self.workers == 0 || worker >= self.workers {
            return 0;
        }
        let elapsed = now_ns.saturating_sub(self.start_ns);
        // ceil((elapsed+1)*rate / 1e9) counts integer-nanosecond arrivals <= now.
        let due = (((elapsed as u128 + 1) * self.rate_per_second as u128).div_ceil(1_000_000_000))
            .min(self.offered() as u128) as u64;
        let assigned = if due <= worker as u64 {
            0
        } else {
            (due - 1 - worker as u64) / self.workers as u64 + 1
        };
        assigned.saturating_sub(completed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fixed_corpus_is_partitioned_without_omission_or_duplication() {
        for workers in 1..9 {
            let plan = ArrivalPlan {
                start_ns: 100,
                duration_ns: 2_000_000_000,
                rate_per_second: 7,
                workers,
            };
            assert_eq!(plan.offered(), 14);
            let mut sequences = Vec::new();
            for worker in 0..workers {
                for local in 0..plan.worker_offered(worker) {
                    sequences.push(local * workers as u64 + worker as u64);
                }
            }
            sequences.sort();
            assert_eq!(sequences, (0..14).collect::<Vec<_>>());
            assert!(plan.scheduled_ns(14).is_none());
        }
    }

    #[test]
    fn slow_completion_accumulates_visible_backlog_instead_of_throttling_arrivals() {
        let plan = ArrivalPlan {
            start_ns: 10,
            duration_ns: 1_000_000_000,
            rate_per_second: 10,
            workers: 2,
        };
        assert_eq!(plan.backlog(0, 0, 9), 0);
        assert_eq!(plan.backlog(0, 0, 10), 1);
        assert_eq!(plan.backlog(1, 0, 10), 0);
        assert_eq!(plan.backlog(0, 1, 900_000_010), 4);
        assert_eq!(plan.backlog(1, 1, u64::MAX), 4);
        assert_eq!(plan.backlog(0, 5, u64::MAX), 0);
    }

    #[test]
    fn fractional_periods_and_admission_boundary_agree() {
        let plan = ArrivalPlan {
            start_ns: 0,
            duration_ns: 1_000_000_000,
            rate_per_second: 3,
            workers: 1,
        };
        assert_eq!(plan.scheduled_ns(1), Some(333_333_333));
        assert_eq!(plan.backlog(0, 0, 333_333_332), 1);
        assert_eq!(plan.backlog(0, 0, 333_333_333), 2);
        assert_eq!(plan.backlog(0, 0, 1_000_000_000), 3);
    }
}
